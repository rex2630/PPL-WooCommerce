<?php 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            

/**
 * CodelistApi
 * PHP version 7.4
 *
 * @category Class
 * @package  PPLCZCPL
 * @author   OpenAPI Generator team
 * @link     https://openapi-generator.tech
 */

/**
 * CPL
 *
 * **Changelog**    * 2024-08-22 - SPRJ-13791 - validace PRTE / PRBC externích čísel - nelze použít najednou    - /shipment/batch    * 2024-07-01 - SPRJ-13838 - přidání    - /customer/address    * 2023-11-23 - SPRJ-12703 - CPL - /shipment - timestamp    - /shipment - Rozšíření výstupu o LastUpdateDate.    * 2023-07-13 - SPRJ-11888 - přidání    - /codelist/status - číselník statusů    * 2023-07-13 - SPRJ-11953 - přidání    - /order/cancel - storno objednávky
 *
 * The version of the OpenAPI document: v1
 * Generated by: https://openapi-generator.tech
 * OpenAPI Generator version: 6.0.1
 */

/**
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */

namespace PPLCZCPL\Api;

use PPLCZVendor\GuzzleHttp\Client;
use PPLCZVendor\GuzzleHttp\ClientInterface;
use PPLCZVendor\GuzzleHttp\Exception\ConnectException;
use PPLCZVendor\GuzzleHttp\Exception\RequestException;
use PPLCZVendor\GuzzleHttp\Psr7\MultipartStream;
use PPLCZVendor\GuzzleHttp\Psr7\Request;
use PPLCZVendor\GuzzleHttp\RequestOptions;
use PPLCZCPL\ApiException;
use PPLCZCPL\Configuration;
use PPLCZCPL\HeaderSelector;
use PPLCZCPL\ObjectSerializerPpl;

/**
 * CodelistApi Class Doc Comment
 *
 * @category Class
 * @package  PPLCZCPL
 * @author   OpenAPI Generator team
 * @link     https://openapi-generator.tech
 */
class CodelistApi
{
    /**
     * @var ClientInterface
     */
    protected $client;

    /**
     * @var Configuration
     */
    protected $config;

    /**
     * @var HeaderSelector
     */
    protected $headerSelector;

    /**
     * @var int Host index
     */
    protected $hostIndex;

    /**
     * @param ClientInterface $client
     * @param Configuration   $config
     * @param HeaderSelector  $selector
     * @param int             $hostIndex (Optional) host index to select the list of hosts if defined in the OpenAPI spec
     */
    public function __construct(
        ClientInterface $client = null,
        Configuration $config = null,
        HeaderSelector $selector = null,
        $hostIndex = 0
    ) {
        $this->client = $client ?: new Client();
        $this->config = $config ?: new Configuration();
        $this->headerSelector = $selector ?: new HeaderSelector();
        $this->hostIndex = $hostIndex;
    }

    /**
     * Set the host index
     *
     * @param int $hostIndex Host index (required)
     */
    public function setHostIndex($hostIndex): void
    {
        $this->hostIndex = $hostIndex;
    }

    /**
     * Get the host index
     *
     * @return int Host index
     */
    public function getHostIndex()
    {
        return $this->hostIndex;
    }

    /**
     * @return Configuration
     */
    public function getConfig()
    {
        return $this->config;
    }

    /**
     * Operation codelistAgeCheckGet
     *
     * Číselník pro službu kontrola věku příjemce
     *
     * @param  int $limit limit (required)
     * @param  int $offset offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistAgeCheckTypeModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel
     */
    public function codelistAgeCheckGet($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        list($response) = $this->codelistAgeCheckGetWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
        return $response;
    }

    /**
     * Operation codelistAgeCheckGetWithHttpInfo
     *
     * Číselník pro službu kontrola věku příjemce
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return array of \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistAgeCheckTypeModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel, HTTP status code, HTTP response headers (array of strings)
     */
    public function codelistAgeCheckGetWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $request = $this->codelistAgeCheckGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        try {
            $options = $this->createHttpClientOption();
            try {
                $response = $this->client->send($request, $options);
            } catch (RequestException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    $e->getResponse() ? $e->getResponse()->getHeaders() : null,
                    $e->getResponse() ? (string) $e->getResponse()->getBody() : null
                );
            } catch (ConnectException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    null,
                    null
                );
            }

            $statusCode = $response->getStatusCode();

            if ($statusCode < 200 || $statusCode > 299) {
                throw new ApiException(
                    sprintf(
                        '[%d] Error connecting to the API (%s)',
                        $statusCode,
                        (string) $request->getUri()
                    ),
                    $statusCode,
                    $response->getHeaders(),
                    (string) $response->getBody()
                );
            }

            switch($statusCode) {
                case 200:
                    if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistAgeCheckTypeModel[]' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistAgeCheckTypeModel[]' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistAgeCheckTypeModel[]', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 400:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 500:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 503:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
            }

            $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistAgeCheckTypeModel[]';
            if ($returnType === '\SplFileObject') {
                $content = $response->getBody(); //stream goes to serializer
            } else {
                $content = (string) $response->getBody();
                if ($returnType !== 'string') {
                    $content = json_decode($content);
                }
            }

            return [
                ObjectSerializerPpl::deserialize($content, $returnType, []),
                $response->getStatusCode(),
                $response->getHeaders()
            ];

        } catch (ApiException $e) {
            switch ($e->getCode()) {
                case 200:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistAgeCheckTypeModel[]',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 400:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 500:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 503:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
            }
            throw $e;
        }
    }

    /**
     * Operation codelistAgeCheckGetAsync
     *
     * Číselník pro službu kontrola věku příjemce
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistAgeCheckGetAsync($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        return $this->codelistAgeCheckGetAsyncWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level)
            ->then(
                function ($response) {
                    return $response[0];
                }
            );
    }

    /**
     * Operation codelistAgeCheckGetAsyncWithHttpInfo
     *
     * Číselník pro službu kontrola věku příjemce
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistAgeCheckGetAsyncWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistAgeCheckTypeModel[]';
        $request = $this->codelistAgeCheckGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        return $this->client
            ->sendAsync($request, $this->createHttpClientOption())
            ->then(
                function ($response) use ($returnType) {
                    if ($returnType === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ($returnType !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, $returnType, []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                },
                function ($exception) {
                    $response = $exception->getResponse();
                    $statusCode = $response->getStatusCode();
                    throw new ApiException(
                        sprintf(
                            '[%d] Error connecting to the API (%s)',
                            $statusCode,
                            $exception->getRequest()->getUri()
                        ),
                        $statusCode,
                        $response->getHeaders(),
                        (string) $response->getBody()
                    );
                }
            );
    }

    /**
     * Create request for operation 'codelistAgeCheckGet'
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Psr7\Request
     */
    public function codelistAgeCheckGetRequest($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        // verify the required parameter 'limit' is set
        if ($limit === null || (is_array($limit) && count($limit) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $limit when calling codelistAgeCheckGet'
            );
        }
        if ($limit > 1000) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistAgeCheckGet, must be smaller than or equal to 1000.');
        }
        if ($limit < 1) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistAgeCheckGet, must be bigger than or equal to 1.');
        }

        // verify the required parameter 'offset' is set
        if ($offset === null || (is_array($offset) && count($offset) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $offset when calling codelistAgeCheckGet'
            );
        }
        if ($offset > 2147483647) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistAgeCheckGet, must be smaller than or equal to 2147483647.');
        }
        if ($offset < 0) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistAgeCheckGet, must be bigger than or equal to 0.');
        }


        $resourcePath = '/codelist/ageCheck';
        $formParams = [];
        $queryParams = [];
        $headerParams = [];
        $httpBody = '';
        $multipart = false;

        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $limit,
            'Limit', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);
        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $offset,
            'Offset', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);

        // header params
        if ($accept_language !== null) {
            $headerParams['Accept-Language'] = ObjectSerializerPpl::toHeaderValue($accept_language);
        }
        // header params
        if ($x_correlation_id !== null) {
            $headerParams['X-Correlation-ID'] = ObjectSerializerPpl::toHeaderValue($x_correlation_id);
        }
        // header params
        if ($x_log_level !== null) {
            $headerParams['X-LogLevel'] = ObjectSerializerPpl::toHeaderValue($x_log_level);
        }



        if ($multipart) {
            $headers = $this->headerSelector->selectHeadersForMultipart(
                ['application/json', 'text/json', 'application/problem+json']
            );
        } else {
            $headers = $this->headerSelector->selectHeaders(
                ['application/json', 'text/json', 'application/problem+json'],
                []
            );
        }

        // for model (json/xml)
        if (count($formParams) > 0) {
            if ($multipart) {
                $multipartContents = [];
                foreach ($formParams as $formParamName => $formParamValue) {
                    $formParamValueItems = is_array($formParamValue) ? $formParamValue : [$formParamValue];
                    foreach ($formParamValueItems as $formParamValueItem) {
                        $multipartContents[] = [
                            'name' => $formParamName,
                            'contents' => $formParamValueItem
                        ];
                    }
                }
                // for HTTP post (form)
                $httpBody = new MultipartStream($multipartContents);

            } elseif ($headers['Content-Type'] === 'application/json') {
                $httpBody = wp_json_encode($formParams);

            } else {
                // for HTTP post (form)
                $httpBody = ObjectSerializerPpl::buildQuery($formParams);
            }
        }

        // this endpoint requires Bearer (JWT) authentication (access token)
        if (!empty($this->config->getAccessToken())) {
            $headers['Authorization'] = 'Bearer ' . $this->config->getAccessToken();
        }

        $defaultHeaders = [];
        if ($this->config->getUserAgent()) {
            $defaultHeaders['User-Agent'] = $this->config->getUserAgent();
        }

        $headers = array_merge(
            $defaultHeaders,
            $headerParams,
            $headers
        );

        $query = ObjectSerializerPpl::buildQuery($queryParams);
        return new Request(
            'GET',
            $this->config->getHost() . $resourcePath . ($query ? "?{$query}" : ''),
            $headers,
            $httpBody
        );
    }

    /**
     * Operation codelistCountryGet
     *
     * Číselník zemí + povolení COD
     *
     * @param  int $limit limit (required)
     * @param  int $offset offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCountryModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel
     */
    public function codelistCountryGet($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        list($response) = $this->codelistCountryGetWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
        return $response;
    }

    /**
     * Operation codelistCountryGetWithHttpInfo
     *
     * Číselník zemí + povolení COD
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return array of \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCountryModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel, HTTP status code, HTTP response headers (array of strings)
     */
    public function codelistCountryGetWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $request = $this->codelistCountryGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        try {
            $options = $this->createHttpClientOption();
            try {
                $response = $this->client->send($request, $options);
            } catch (RequestException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    $e->getResponse() ? $e->getResponse()->getHeaders() : null,
                    $e->getResponse() ? (string) $e->getResponse()->getBody() : null
                );
            } catch (ConnectException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    null,
                    null
                );
            }

            $statusCode = $response->getStatusCode();

            if ($statusCode < 200 || $statusCode > 299) {
                throw new ApiException(
                    sprintf(
                        '[%d] Error connecting to the API (%s)',
                        $statusCode,
                        (string) $request->getUri()
                    ),
                    $statusCode,
                    $response->getHeaders(),
                    (string) $response->getBody()
                );
            }

            switch($statusCode) {
                case 200:
                    if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCountryModel[]' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCountryModel[]' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCountryModel[]', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 400:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 500:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 503:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
            }

            $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCountryModel[]';
            if ($returnType === '\SplFileObject') {
                $content = $response->getBody(); //stream goes to serializer
            } else {
                $content = (string) $response->getBody();
                if ($returnType !== 'string') {
                    $content = json_decode($content);
                }
            }

            return [
                ObjectSerializerPpl::deserialize($content, $returnType, []),
                $response->getStatusCode(),
                $response->getHeaders()
            ];

        } catch (ApiException $e) {
            switch ($e->getCode()) {
                case 200:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCountryModel[]',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 400:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 500:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 503:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
            }
            throw $e;
        }
    }

    /**
     * Operation codelistCountryGetAsync
     *
     * Číselník zemí + povolení COD
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistCountryGetAsync($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        return $this->codelistCountryGetAsyncWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level)
            ->then(
                function ($response) {
                    return $response[0];
                }
            );
    }

    /**
     * Operation codelistCountryGetAsyncWithHttpInfo
     *
     * Číselník zemí + povolení COD
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistCountryGetAsyncWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCountryModel[]';
        $request = $this->codelistCountryGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        return $this->client
            ->sendAsync($request, $this->createHttpClientOption())
            ->then(
                function ($response) use ($returnType) {
                    if ($returnType === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ($returnType !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, $returnType, []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                },
                function ($exception) {
                    $response = $exception->getResponse();
                    $statusCode = $response->getStatusCode();
                    throw new ApiException(
                        sprintf(
                            '[%d] Error connecting to the API (%s)',
                            $statusCode,
                            $exception->getRequest()->getUri()
                        ),
                        $statusCode,
                        $response->getHeaders(),
                        (string) $response->getBody()
                    );
                }
            );
    }

    /**
     * Create request for operation 'codelistCountryGet'
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Psr7\Request
     */
    public function codelistCountryGetRequest($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        // verify the required parameter 'limit' is set
        if ($limit === null || (is_array($limit) && count($limit) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $limit when calling codelistCountryGet'
            );
        }
        if ($limit > 1000) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistCountryGet, must be smaller than or equal to 1000.');
        }
        if ($limit < 1) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistCountryGet, must be bigger than or equal to 1.');
        }

        // verify the required parameter 'offset' is set
        if ($offset === null || (is_array($offset) && count($offset) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $offset when calling codelistCountryGet'
            );
        }
        if ($offset > 2147483647) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistCountryGet, must be smaller than or equal to 2147483647.');
        }
        if ($offset < 0) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistCountryGet, must be bigger than or equal to 0.');
        }


        $resourcePath = '/codelist/country';
        $formParams = [];
        $queryParams = [];
        $headerParams = [];
        $httpBody = '';
        $multipart = false;

        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $limit,
            'Limit', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);
        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $offset,
            'Offset', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);

        // header params
        if ($accept_language !== null) {
            $headerParams['Accept-Language'] = ObjectSerializerPpl::toHeaderValue($accept_language);
        }
        // header params
        if ($x_correlation_id !== null) {
            $headerParams['X-Correlation-ID'] = ObjectSerializerPpl::toHeaderValue($x_correlation_id);
        }
        // header params
        if ($x_log_level !== null) {
            $headerParams['X-LogLevel'] = ObjectSerializerPpl::toHeaderValue($x_log_level);
        }



        if ($multipart) {
            $headers = $this->headerSelector->selectHeadersForMultipart(
                ['application/json', 'text/json', 'application/problem+json']
            );
        } else {
            $headers = $this->headerSelector->selectHeaders(
                ['application/json', 'text/json', 'application/problem+json'],
                []
            );
        }

        // for model (json/xml)
        if (count($formParams) > 0) {
            if ($multipart) {
                $multipartContents = [];
                foreach ($formParams as $formParamName => $formParamValue) {
                    $formParamValueItems = is_array($formParamValue) ? $formParamValue : [$formParamValue];
                    foreach ($formParamValueItems as $formParamValueItem) {
                        $multipartContents[] = [
                            'name' => $formParamName,
                            'contents' => $formParamValueItem
                        ];
                    }
                }
                // for HTTP post (form)
                $httpBody = new MultipartStream($multipartContents);

            } elseif ($headers['Content-Type'] === 'application/json') {
                $httpBody = wp_json_encode($formParams);

            } else {
                // for HTTP post (form)
                $httpBody = ObjectSerializerPpl::buildQuery($formParams);
            }
        }

        // this endpoint requires Bearer (JWT) authentication (access token)
        if (!empty($this->config->getAccessToken())) {
            $headers['Authorization'] = 'Bearer ' . $this->config->getAccessToken();
        }

        $defaultHeaders = [];
        if ($this->config->getUserAgent()) {
            $defaultHeaders['User-Agent'] = $this->config->getUserAgent();
        }

        $headers = array_merge(
            $defaultHeaders,
            $headerParams,
            $headers
        );

        $query = ObjectSerializerPpl::buildQuery($queryParams);
        return new Request(
            'GET',
            $this->config->getHost() . $resourcePath . ($query ? "?{$query}" : ''),
            $headers,
            $httpBody
        );
    }

    /**
     * Operation codelistCurrencyGet
     *
     * Číselník povolených měn
     *
     * @param  int $limit limit (required)
     * @param  int $offset offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCurrencyModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel
     */
    public function codelistCurrencyGet($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        list($response) = $this->codelistCurrencyGetWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
        return $response;
    }

    /**
     * Operation codelistCurrencyGetWithHttpInfo
     *
     * Číselník povolených měn
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return array of \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCurrencyModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel, HTTP status code, HTTP response headers (array of strings)
     */
    public function codelistCurrencyGetWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $request = $this->codelistCurrencyGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        try {
            $options = $this->createHttpClientOption();
            try {
                $response = $this->client->send($request, $options);
            } catch (RequestException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    $e->getResponse() ? $e->getResponse()->getHeaders() : null,
                    $e->getResponse() ? (string) $e->getResponse()->getBody() : null
                );
            } catch (ConnectException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    null,
                    null
                );
            }

            $statusCode = $response->getStatusCode();

            if ($statusCode < 200 || $statusCode > 299) {
                throw new ApiException(
                    sprintf(
                        '[%d] Error connecting to the API (%s)',
                        $statusCode,
                        (string) $request->getUri()
                    ),
                    $statusCode,
                    $response->getHeaders(),
                    (string) $response->getBody()
                );
            }

            switch($statusCode) {
                case 200:
                    if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCurrencyModel[]' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCurrencyModel[]' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCurrencyModel[]', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 400:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 500:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 503:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
            }

            $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCurrencyModel[]';
            if ($returnType === '\SplFileObject') {
                $content = $response->getBody(); //stream goes to serializer
            } else {
                $content = (string) $response->getBody();
                if ($returnType !== 'string') {
                    $content = json_decode($content);
                }
            }

            return [
                ObjectSerializerPpl::deserialize($content, $returnType, []),
                $response->getStatusCode(),
                $response->getHeaders()
            ];

        } catch (ApiException $e) {
            switch ($e->getCode()) {
                case 200:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCurrencyModel[]',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 400:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 500:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 503:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
            }
            throw $e;
        }
    }

    /**
     * Operation codelistCurrencyGetAsync
     *
     * Číselník povolených měn
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistCurrencyGetAsync($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        return $this->codelistCurrencyGetAsyncWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level)
            ->then(
                function ($response) {
                    return $response[0];
                }
            );
    }

    /**
     * Operation codelistCurrencyGetAsyncWithHttpInfo
     *
     * Číselník povolených měn
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistCurrencyGetAsyncWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistCurrencyModel[]';
        $request = $this->codelistCurrencyGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        return $this->client
            ->sendAsync($request, $this->createHttpClientOption())
            ->then(
                function ($response) use ($returnType) {
                    if ($returnType === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ($returnType !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, $returnType, []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                },
                function ($exception) {
                    $response = $exception->getResponse();
                    $statusCode = $response->getStatusCode();
                    throw new ApiException(
                        sprintf(
                            '[%d] Error connecting to the API (%s)',
                            $statusCode,
                            $exception->getRequest()->getUri()
                        ),
                        $statusCode,
                        $response->getHeaders(),
                        (string) $response->getBody()
                    );
                }
            );
    }

    /**
     * Create request for operation 'codelistCurrencyGet'
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Psr7\Request
     */
    public function codelistCurrencyGetRequest($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        // verify the required parameter 'limit' is set
        if ($limit === null || (is_array($limit) && count($limit) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $limit when calling codelistCurrencyGet'
            );
        }
        if ($limit > 1000) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistCurrencyGet, must be smaller than or equal to 1000.');
        }
        if ($limit < 1) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistCurrencyGet, must be bigger than or equal to 1.');
        }

        // verify the required parameter 'offset' is set
        if ($offset === null || (is_array($offset) && count($offset) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $offset when calling codelistCurrencyGet'
            );
        }
        if ($offset > 2147483647) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistCurrencyGet, must be smaller than or equal to 2147483647.');
        }
        if ($offset < 0) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistCurrencyGet, must be bigger than or equal to 0.');
        }


        $resourcePath = '/codelist/currency';
        $formParams = [];
        $queryParams = [];
        $headerParams = [];
        $httpBody = '';
        $multipart = false;

        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $limit,
            'Limit', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);
        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $offset,
            'Offset', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);

        // header params
        if ($accept_language !== null) {
            $headerParams['Accept-Language'] = ObjectSerializerPpl::toHeaderValue($accept_language);
        }
        // header params
        if ($x_correlation_id !== null) {
            $headerParams['X-Correlation-ID'] = ObjectSerializerPpl::toHeaderValue($x_correlation_id);
        }
        // header params
        if ($x_log_level !== null) {
            $headerParams['X-LogLevel'] = ObjectSerializerPpl::toHeaderValue($x_log_level);
        }



        if ($multipart) {
            $headers = $this->headerSelector->selectHeadersForMultipart(
                ['application/json', 'text/json', 'application/problem+json']
            );
        } else {
            $headers = $this->headerSelector->selectHeaders(
                ['application/json', 'text/json', 'application/problem+json'],
                []
            );
        }

        // for model (json/xml)
        if (count($formParams) > 0) {
            if ($multipart) {
                $multipartContents = [];
                foreach ($formParams as $formParamName => $formParamValue) {
                    $formParamValueItems = is_array($formParamValue) ? $formParamValue : [$formParamValue];
                    foreach ($formParamValueItems as $formParamValueItem) {
                        $multipartContents[] = [
                            'name' => $formParamName,
                            'contents' => $formParamValueItem
                        ];
                    }
                }
                // for HTTP post (form)
                $httpBody = new MultipartStream($multipartContents);

            } elseif ($headers['Content-Type'] === 'application/json') {
                $httpBody = wp_json_encode($formParams);

            } else {
                // for HTTP post (form)
                $httpBody = ObjectSerializerPpl::buildQuery($formParams);
            }
        }

        // this endpoint requires Bearer (JWT) authentication (access token)
        if (!empty($this->config->getAccessToken())) {
            $headers['Authorization'] = 'Bearer ' . $this->config->getAccessToken();
        }

        $defaultHeaders = [];
        if ($this->config->getUserAgent()) {
            $defaultHeaders['User-Agent'] = $this->config->getUserAgent();
        }

        $headers = array_merge(
            $defaultHeaders,
            $headerParams,
            $headers
        );

        $query = ObjectSerializerPpl::buildQuery($queryParams);
        return new Request(
            'GET',
            $this->config->getHost() . $resourcePath . ($query ? "?{$query}" : ''),
            $headers,
            $httpBody
        );
    }

    /**
     * Operation codelistExternalNumberGet
     *
     * Číselník typu externích čísel
     *
     * @param  int $limit limit (required)
     * @param  int $offset offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentExternalNumberTypeModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel
     */
    public function codelistExternalNumberGet($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        list($response) = $this->codelistExternalNumberGetWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
        return $response;
    }

    /**
     * Operation codelistExternalNumberGetWithHttpInfo
     *
     * Číselník typu externích čísel
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return array of \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentExternalNumberTypeModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel, HTTP status code, HTTP response headers (array of strings)
     */
    public function codelistExternalNumberGetWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $request = $this->codelistExternalNumberGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        try {
            $options = $this->createHttpClientOption();
            try {
                $response = $this->client->send($request, $options);
            } catch (RequestException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    $e->getResponse() ? $e->getResponse()->getHeaders() : null,
                    $e->getResponse() ? (string) $e->getResponse()->getBody() : null
                );
            } catch (ConnectException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    null,
                    null
                );
            }

            $statusCode = $response->getStatusCode();

            if ($statusCode < 200 || $statusCode > 299) {
                throw new ApiException(
                    sprintf(
                        '[%d] Error connecting to the API (%s)',
                        $statusCode,
                        (string) $request->getUri()
                    ),
                    $statusCode,
                    $response->getHeaders(),
                    (string) $response->getBody()
                );
            }

            switch($statusCode) {
                case 200:
                    if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentExternalNumberTypeModel[]' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentExternalNumberTypeModel[]' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentExternalNumberTypeModel[]', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 400:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 500:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 503:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
            }

            $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentExternalNumberTypeModel[]';
            if ($returnType === '\SplFileObject') {
                $content = $response->getBody(); //stream goes to serializer
            } else {
                $content = (string) $response->getBody();
                if ($returnType !== 'string') {
                    $content = json_decode($content);
                }
            }

            return [
                ObjectSerializerPpl::deserialize($content, $returnType, []),
                $response->getStatusCode(),
                $response->getHeaders()
            ];

        } catch (ApiException $e) {
            switch ($e->getCode()) {
                case 200:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentExternalNumberTypeModel[]',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 400:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 500:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 503:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
            }
            throw $e;
        }
    }

    /**
     * Operation codelistExternalNumberGetAsync
     *
     * Číselník typu externích čísel
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistExternalNumberGetAsync($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        return $this->codelistExternalNumberGetAsyncWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level)
            ->then(
                function ($response) {
                    return $response[0];
                }
            );
    }

    /**
     * Operation codelistExternalNumberGetAsyncWithHttpInfo
     *
     * Číselník typu externích čísel
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistExternalNumberGetAsyncWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentExternalNumberTypeModel[]';
        $request = $this->codelistExternalNumberGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        return $this->client
            ->sendAsync($request, $this->createHttpClientOption())
            ->then(
                function ($response) use ($returnType) {
                    if ($returnType === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ($returnType !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, $returnType, []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                },
                function ($exception) {
                    $response = $exception->getResponse();
                    $statusCode = $response->getStatusCode();
                    throw new ApiException(
                        sprintf(
                            '[%d] Error connecting to the API (%s)',
                            $statusCode,
                            $exception->getRequest()->getUri()
                        ),
                        $statusCode,
                        $response->getHeaders(),
                        (string) $response->getBody()
                    );
                }
            );
    }

    /**
     * Create request for operation 'codelistExternalNumberGet'
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Psr7\Request
     */
    public function codelistExternalNumberGetRequest($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        // verify the required parameter 'limit' is set
        if ($limit === null || (is_array($limit) && count($limit) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $limit when calling codelistExternalNumberGet'
            );
        }
        if ($limit > 1000) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistExternalNumberGet, must be smaller than or equal to 1000.');
        }
        if ($limit < 1) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistExternalNumberGet, must be bigger than or equal to 1.');
        }

        // verify the required parameter 'offset' is set
        if ($offset === null || (is_array($offset) && count($offset) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $offset when calling codelistExternalNumberGet'
            );
        }
        if ($offset > 2147483647) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistExternalNumberGet, must be smaller than or equal to 2147483647.');
        }
        if ($offset < 0) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistExternalNumberGet, must be bigger than or equal to 0.');
        }


        $resourcePath = '/codelist/externalNumber';
        $formParams = [];
        $queryParams = [];
        $headerParams = [];
        $httpBody = '';
        $multipart = false;

        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $limit,
            'Limit', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);
        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $offset,
            'Offset', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);

        // header params
        if ($accept_language !== null) {
            $headerParams['Accept-Language'] = ObjectSerializerPpl::toHeaderValue($accept_language);
        }
        // header params
        if ($x_correlation_id !== null) {
            $headerParams['X-Correlation-ID'] = ObjectSerializerPpl::toHeaderValue($x_correlation_id);
        }
        // header params
        if ($x_log_level !== null) {
            $headerParams['X-LogLevel'] = ObjectSerializerPpl::toHeaderValue($x_log_level);
        }



        if ($multipart) {
            $headers = $this->headerSelector->selectHeadersForMultipart(
                ['application/json', 'text/json', 'application/problem+json']
            );
        } else {
            $headers = $this->headerSelector->selectHeaders(
                ['application/json', 'text/json', 'application/problem+json'],
                []
            );
        }

        // for model (json/xml)
        if (count($formParams) > 0) {
            if ($multipart) {
                $multipartContents = [];
                foreach ($formParams as $formParamName => $formParamValue) {
                    $formParamValueItems = is_array($formParamValue) ? $formParamValue : [$formParamValue];
                    foreach ($formParamValueItems as $formParamValueItem) {
                        $multipartContents[] = [
                            'name' => $formParamName,
                            'contents' => $formParamValueItem
                        ];
                    }
                }
                // for HTTP post (form)
                $httpBody = new MultipartStream($multipartContents);

            } elseif ($headers['Content-Type'] === 'application/json') {
                $httpBody = wp_json_encode($formParams);

            } else {
                // for HTTP post (form)
                $httpBody = ObjectSerializerPpl::buildQuery($formParams);
            }
        }

        // this endpoint requires Bearer (JWT) authentication (access token)
        if (!empty($this->config->getAccessToken())) {
            $headers['Authorization'] = 'Bearer ' . $this->config->getAccessToken();
        }

        $defaultHeaders = [];
        if ($this->config->getUserAgent()) {
            $defaultHeaders['User-Agent'] = $this->config->getUserAgent();
        }

        $headers = array_merge(
            $defaultHeaders,
            $headerParams,
            $headers
        );

        $query = ObjectSerializerPpl::buildQuery($queryParams);
        return new Request(
            'GET',
            $this->config->getHost() . $resourcePath . ($query ? "?{$query}" : ''),
            $headers,
            $httpBody
        );
    }

    /**
     * Operation codelistProductGet
     *
     * Číselník produktů
     *
     * @param  int $limit limit (required)
     * @param  int $offset offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentProductType[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel
     */
    public function codelistProductGet($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        list($response) = $this->codelistProductGetWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
        return $response;
    }

    /**
     * Operation codelistProductGetWithHttpInfo
     *
     * Číselník produktů
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return array of \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentProductType[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel, HTTP status code, HTTP response headers (array of strings)
     */
    public function codelistProductGetWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $request = $this->codelistProductGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        try {
            $options = $this->createHttpClientOption();
            try {
                $response = $this->client->send($request, $options);
            } catch (RequestException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    $e->getResponse() ? $e->getResponse()->getHeaders() : null,
                    $e->getResponse() ? (string) $e->getResponse()->getBody() : null
                );
            } catch (ConnectException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    null,
                    null
                );
            }

            $statusCode = $response->getStatusCode();

            if ($statusCode < 200 || $statusCode > 299) {
                throw new ApiException(
                    sprintf(
                        '[%d] Error connecting to the API (%s)',
                        $statusCode,
                        (string) $request->getUri()
                    ),
                    $statusCode,
                    $response->getHeaders(),
                    (string) $response->getBody()
                );
            }

            switch($statusCode) {
                case 200:
                    if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentProductType[]' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentProductType[]' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentProductType[]', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 400:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 500:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 503:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
            }

            $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentProductType[]';
            if ($returnType === '\SplFileObject') {
                $content = $response->getBody(); //stream goes to serializer
            } else {
                $content = (string) $response->getBody();
                if ($returnType !== 'string') {
                    $content = json_decode($content);
                }
            }

            return [
                ObjectSerializerPpl::deserialize($content, $returnType, []),
                $response->getStatusCode(),
                $response->getHeaders()
            ];

        } catch (ApiException $e) {
            switch ($e->getCode()) {
                case 200:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentProductType[]',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 400:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 500:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 503:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
            }
            throw $e;
        }
    }

    /**
     * Operation codelistProductGetAsync
     *
     * Číselník produktů
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistProductGetAsync($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        return $this->codelistProductGetAsyncWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level)
            ->then(
                function ($response) {
                    return $response[0];
                }
            );
    }

    /**
     * Operation codelistProductGetAsyncWithHttpInfo
     *
     * Číselník produktů
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistProductGetAsyncWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentProductType[]';
        $request = $this->codelistProductGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        return $this->client
            ->sendAsync($request, $this->createHttpClientOption())
            ->then(
                function ($response) use ($returnType) {
                    if ($returnType === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ($returnType !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, $returnType, []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                },
                function ($exception) {
                    $response = $exception->getResponse();
                    $statusCode = $response->getStatusCode();
                    throw new ApiException(
                        sprintf(
                            '[%d] Error connecting to the API (%s)',
                            $statusCode,
                            $exception->getRequest()->getUri()
                        ),
                        $statusCode,
                        $response->getHeaders(),
                        (string) $response->getBody()
                    );
                }
            );
    }

    /**
     * Create request for operation 'codelistProductGet'
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Psr7\Request
     */
    public function codelistProductGetRequest($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        // verify the required parameter 'limit' is set
        if ($limit === null || (is_array($limit) && count($limit) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $limit when calling codelistProductGet'
            );
        }
        if ($limit > 1000) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistProductGet, must be smaller than or equal to 1000.');
        }
        if ($limit < 1) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistProductGet, must be bigger than or equal to 1.');
        }

        // verify the required parameter 'offset' is set
        if ($offset === null || (is_array($offset) && count($offset) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $offset when calling codelistProductGet'
            );
        }
        if ($offset > 2147483647) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistProductGet, must be smaller than or equal to 2147483647.');
        }
        if ($offset < 0) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistProductGet, must be bigger than or equal to 0.');
        }


        $resourcePath = '/codelist/product';
        $formParams = [];
        $queryParams = [];
        $headerParams = [];
        $httpBody = '';
        $multipart = false;

        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $limit,
            'Limit', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);
        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $offset,
            'Offset', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);

        // header params
        if ($accept_language !== null) {
            $headerParams['Accept-Language'] = ObjectSerializerPpl::toHeaderValue($accept_language);
        }
        // header params
        if ($x_correlation_id !== null) {
            $headerParams['X-Correlation-ID'] = ObjectSerializerPpl::toHeaderValue($x_correlation_id);
        }
        // header params
        if ($x_log_level !== null) {
            $headerParams['X-LogLevel'] = ObjectSerializerPpl::toHeaderValue($x_log_level);
        }



        if ($multipart) {
            $headers = $this->headerSelector->selectHeadersForMultipart(
                ['application/json', 'text/json', 'application/problem+json']
            );
        } else {
            $headers = $this->headerSelector->selectHeaders(
                ['application/json', 'text/json', 'application/problem+json'],
                []
            );
        }

        // for model (json/xml)
        if (count($formParams) > 0) {
            if ($multipart) {
                $multipartContents = [];
                foreach ($formParams as $formParamName => $formParamValue) {
                    $formParamValueItems = is_array($formParamValue) ? $formParamValue : [$formParamValue];
                    foreach ($formParamValueItems as $formParamValueItem) {
                        $multipartContents[] = [
                            'name' => $formParamName,
                            'contents' => $formParamValueItem
                        ];
                    }
                }
                // for HTTP post (form)
                $httpBody = new MultipartStream($multipartContents);

            } elseif ($headers['Content-Type'] === 'application/json') {
                $httpBody = wp_json_encode($formParams);

            } else {
                // for HTTP post (form)
                $httpBody = ObjectSerializerPpl::buildQuery($formParams);
            }
        }

        // this endpoint requires Bearer (JWT) authentication (access token)
        if (!empty($this->config->getAccessToken())) {
            $headers['Authorization'] = 'Bearer ' . $this->config->getAccessToken();
        }

        $defaultHeaders = [];
        if ($this->config->getUserAgent()) {
            $defaultHeaders['User-Agent'] = $this->config->getUserAgent();
        }

        $headers = array_merge(
            $defaultHeaders,
            $headerParams,
            $headers
        );

        $query = ObjectSerializerPpl::buildQuery($queryParams);
        return new Request(
            'GET',
            $this->config->getHost() . $resourcePath . ($query ? "?{$query}" : ''),
            $headers,
            $httpBody
        );
    }

    /**
     * Operation codelistProofOfIdentityTypeGet
     *
     * Typy osobních dokladů
     *
     * @param  int $limit limit (required)
     * @param  int $offset offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistProofOfIdentityTypeModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel
     */
    public function codelistProofOfIdentityTypeGet($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        list($response) = $this->codelistProofOfIdentityTypeGetWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
        return $response;
    }

    /**
     * Operation codelistProofOfIdentityTypeGetWithHttpInfo
     *
     * Typy osobních dokladů
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return array of \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistProofOfIdentityTypeModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel, HTTP status code, HTTP response headers (array of strings)
     */
    public function codelistProofOfIdentityTypeGetWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $request = $this->codelistProofOfIdentityTypeGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        try {
            $options = $this->createHttpClientOption();
            try {
                $response = $this->client->send($request, $options);
            } catch (RequestException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    $e->getResponse() ? $e->getResponse()->getHeaders() : null,
                    $e->getResponse() ? (string) $e->getResponse()->getBody() : null
                );
            } catch (ConnectException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    null,
                    null
                );
            }

            $statusCode = $response->getStatusCode();

            if ($statusCode < 200 || $statusCode > 299) {
                throw new ApiException(
                    sprintf(
                        '[%d] Error connecting to the API (%s)',
                        $statusCode,
                        (string) $request->getUri()
                    ),
                    $statusCode,
                    $response->getHeaders(),
                    (string) $response->getBody()
                );
            }

            switch($statusCode) {
                case 200:
                    if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistProofOfIdentityTypeModel[]' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistProofOfIdentityTypeModel[]' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistProofOfIdentityTypeModel[]', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 400:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 500:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 503:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
            }

            $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistProofOfIdentityTypeModel[]';
            if ($returnType === '\SplFileObject') {
                $content = $response->getBody(); //stream goes to serializer
            } else {
                $content = (string) $response->getBody();
                if ($returnType !== 'string') {
                    $content = json_decode($content);
                }
            }

            return [
                ObjectSerializerPpl::deserialize($content, $returnType, []),
                $response->getStatusCode(),
                $response->getHeaders()
            ];

        } catch (ApiException $e) {
            switch ($e->getCode()) {
                case 200:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistProofOfIdentityTypeModel[]',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 400:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 500:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 503:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
            }
            throw $e;
        }
    }

    /**
     * Operation codelistProofOfIdentityTypeGetAsync
     *
     * Typy osobních dokladů
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistProofOfIdentityTypeGetAsync($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        return $this->codelistProofOfIdentityTypeGetAsyncWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level)
            ->then(
                function ($response) {
                    return $response[0];
                }
            );
    }

    /**
     * Operation codelistProofOfIdentityTypeGetAsyncWithHttpInfo
     *
     * Typy osobních dokladů
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistProofOfIdentityTypeGetAsyncWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistProofOfIdentityTypeModel[]';
        $request = $this->codelistProofOfIdentityTypeGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        return $this->client
            ->sendAsync($request, $this->createHttpClientOption())
            ->then(
                function ($response) use ($returnType) {
                    if ($returnType === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ($returnType !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, $returnType, []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                },
                function ($exception) {
                    $response = $exception->getResponse();
                    $statusCode = $response->getStatusCode();
                    throw new ApiException(
                        sprintf(
                            '[%d] Error connecting to the API (%s)',
                            $statusCode,
                            $exception->getRequest()->getUri()
                        ),
                        $statusCode,
                        $response->getHeaders(),
                        (string) $response->getBody()
                    );
                }
            );
    }

    /**
     * Create request for operation 'codelistProofOfIdentityTypeGet'
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Psr7\Request
     */
    public function codelistProofOfIdentityTypeGetRequest($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        // verify the required parameter 'limit' is set
        if ($limit === null || (is_array($limit) && count($limit) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $limit when calling codelistProofOfIdentityTypeGet'
            );
        }
        if ($limit > 1000) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistProofOfIdentityTypeGet, must be smaller than or equal to 1000.');
        }
        if ($limit < 1) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistProofOfIdentityTypeGet, must be bigger than or equal to 1.');
        }

        // verify the required parameter 'offset' is set
        if ($offset === null || (is_array($offset) && count($offset) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $offset when calling codelistProofOfIdentityTypeGet'
            );
        }
        if ($offset > 2147483647) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistProofOfIdentityTypeGet, must be smaller than or equal to 2147483647.');
        }
        if ($offset < 0) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistProofOfIdentityTypeGet, must be bigger than or equal to 0.');
        }


        $resourcePath = '/codelist/proofOfIdentityType';
        $formParams = [];
        $queryParams = [];
        $headerParams = [];
        $httpBody = '';
        $multipart = false;

        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $limit,
            'Limit', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);
        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $offset,
            'Offset', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);

        // header params
        if ($accept_language !== null) {
            $headerParams['Accept-Language'] = ObjectSerializerPpl::toHeaderValue($accept_language);
        }
        // header params
        if ($x_correlation_id !== null) {
            $headerParams['X-Correlation-ID'] = ObjectSerializerPpl::toHeaderValue($x_correlation_id);
        }
        // header params
        if ($x_log_level !== null) {
            $headerParams['X-LogLevel'] = ObjectSerializerPpl::toHeaderValue($x_log_level);
        }



        if ($multipart) {
            $headers = $this->headerSelector->selectHeadersForMultipart(
                ['application/json', 'text/json', 'application/problem+json']
            );
        } else {
            $headers = $this->headerSelector->selectHeaders(
                ['application/json', 'text/json', 'application/problem+json'],
                []
            );
        }

        // for model (json/xml)
        if (count($formParams) > 0) {
            if ($multipart) {
                $multipartContents = [];
                foreach ($formParams as $formParamName => $formParamValue) {
                    $formParamValueItems = is_array($formParamValue) ? $formParamValue : [$formParamValue];
                    foreach ($formParamValueItems as $formParamValueItem) {
                        $multipartContents[] = [
                            'name' => $formParamName,
                            'contents' => $formParamValueItem
                        ];
                    }
                }
                // for HTTP post (form)
                $httpBody = new MultipartStream($multipartContents);

            } elseif ($headers['Content-Type'] === 'application/json') {
                $httpBody = wp_json_encode($formParams);

            } else {
                // for HTTP post (form)
                $httpBody = ObjectSerializerPpl::buildQuery($formParams);
            }
        }

        // this endpoint requires Bearer (JWT) authentication (access token)
        if (!empty($this->config->getAccessToken())) {
            $headers['Authorization'] = 'Bearer ' . $this->config->getAccessToken();
        }

        $defaultHeaders = [];
        if ($this->config->getUserAgent()) {
            $defaultHeaders['User-Agent'] = $this->config->getUserAgent();
        }

        $headers = array_merge(
            $defaultHeaders,
            $headerParams,
            $headers
        );

        $query = ObjectSerializerPpl::buildQuery($queryParams);
        return new Request(
            'GET',
            $this->config->getHost() . $resourcePath . ($query ? "?{$query}" : ''),
            $headers,
            $httpBody
        );
    }

    /**
     * Operation codelistServiceGet
     *
     * Metoda pro získání poskytovaných služeb k zásilkám. Vyskytuje se u shipment/batch nebo /shipment
     *
     * @param  int $limit limit (required)
     * @param  int $offset offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentServiceModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel
     */
    public function codelistServiceGet($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        list($response) = $this->codelistServiceGetWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
        return $response;
    }

    /**
     * Operation codelistServiceGetWithHttpInfo
     *
     * Metoda pro získání poskytovaných služeb k zásilkám. Vyskytuje se u shipment/batch nebo /shipment
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return array of \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentServiceModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel, HTTP status code, HTTP response headers (array of strings)
     */
    public function codelistServiceGetWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $request = $this->codelistServiceGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        try {
            $options = $this->createHttpClientOption();
            try {
                $response = $this->client->send($request, $options);
            } catch (RequestException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    $e->getResponse() ? $e->getResponse()->getHeaders() : null,
                    $e->getResponse() ? (string) $e->getResponse()->getBody() : null
                );
            } catch (ConnectException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    null,
                    null
                );
            }

            $statusCode = $response->getStatusCode();

            if ($statusCode < 200 || $statusCode > 299) {
                throw new ApiException(
                    sprintf(
                        '[%d] Error connecting to the API (%s)',
                        $statusCode,
                        (string) $request->getUri()
                    ),
                    $statusCode,
                    $response->getHeaders(),
                    (string) $response->getBody()
                );
            }

            switch($statusCode) {
                case 200:
                    if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentServiceModel[]' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentServiceModel[]' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentServiceModel[]', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 400:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 500:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 503:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
            }

            $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentServiceModel[]';
            if ($returnType === '\SplFileObject') {
                $content = $response->getBody(); //stream goes to serializer
            } else {
                $content = (string) $response->getBody();
                if ($returnType !== 'string') {
                    $content = json_decode($content);
                }
            }

            return [
                ObjectSerializerPpl::deserialize($content, $returnType, []),
                $response->getStatusCode(),
                $response->getHeaders()
            ];

        } catch (ApiException $e) {
            switch ($e->getCode()) {
                case 200:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentServiceModel[]',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 400:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 500:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 503:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
            }
            throw $e;
        }
    }

    /**
     * Operation codelistServiceGetAsync
     *
     * Metoda pro získání poskytovaných služeb k zásilkám. Vyskytuje se u shipment/batch nebo /shipment
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistServiceGetAsync($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        return $this->codelistServiceGetAsyncWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level)
            ->then(
                function ($response) {
                    return $response[0];
                }
            );
    }

    /**
     * Operation codelistServiceGetAsyncWithHttpInfo
     *
     * Metoda pro získání poskytovaných služeb k zásilkám. Vyskytuje se u shipment/batch nebo /shipment
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistServiceGetAsyncWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentServiceModel[]';
        $request = $this->codelistServiceGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        return $this->client
            ->sendAsync($request, $this->createHttpClientOption())
            ->then(
                function ($response) use ($returnType) {
                    if ($returnType === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ($returnType !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, $returnType, []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                },
                function ($exception) {
                    $response = $exception->getResponse();
                    $statusCode = $response->getStatusCode();
                    throw new ApiException(
                        sprintf(
                            '[%d] Error connecting to the API (%s)',
                            $statusCode,
                            $exception->getRequest()->getUri()
                        ),
                        $statusCode,
                        $response->getHeaders(),
                        (string) $response->getBody()
                    );
                }
            );
    }

    /**
     * Create request for operation 'codelistServiceGet'
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Psr7\Request
     */
    public function codelistServiceGetRequest($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        // verify the required parameter 'limit' is set
        if ($limit === null || (is_array($limit) && count($limit) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $limit when calling codelistServiceGet'
            );
        }
        if ($limit > 1000) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistServiceGet, must be smaller than or equal to 1000.');
        }
        if ($limit < 1) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistServiceGet, must be bigger than or equal to 1.');
        }

        // verify the required parameter 'offset' is set
        if ($offset === null || (is_array($offset) && count($offset) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $offset when calling codelistServiceGet'
            );
        }
        if ($offset > 2147483647) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistServiceGet, must be smaller than or equal to 2147483647.');
        }
        if ($offset < 0) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistServiceGet, must be bigger than or equal to 0.');
        }


        $resourcePath = '/codelist/service';
        $formParams = [];
        $queryParams = [];
        $headerParams = [];
        $httpBody = '';
        $multipart = false;

        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $limit,
            'Limit', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);
        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $offset,
            'Offset', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);

        // header params
        if ($accept_language !== null) {
            $headerParams['Accept-Language'] = ObjectSerializerPpl::toHeaderValue($accept_language);
        }
        // header params
        if ($x_correlation_id !== null) {
            $headerParams['X-Correlation-ID'] = ObjectSerializerPpl::toHeaderValue($x_correlation_id);
        }
        // header params
        if ($x_log_level !== null) {
            $headerParams['X-LogLevel'] = ObjectSerializerPpl::toHeaderValue($x_log_level);
        }



        if ($multipart) {
            $headers = $this->headerSelector->selectHeadersForMultipart(
                ['application/json', 'text/json', 'application/problem+json']
            );
        } else {
            $headers = $this->headerSelector->selectHeaders(
                ['application/json', 'text/json', 'application/problem+json'],
                []
            );
        }

        // for model (json/xml)
        if (count($formParams) > 0) {
            if ($multipart) {
                $multipartContents = [];
                foreach ($formParams as $formParamName => $formParamValue) {
                    $formParamValueItems = is_array($formParamValue) ? $formParamValue : [$formParamValue];
                    foreach ($formParamValueItems as $formParamValueItem) {
                        $multipartContents[] = [
                            'name' => $formParamName,
                            'contents' => $formParamValueItem
                        ];
                    }
                }
                // for HTTP post (form)
                $httpBody = new MultipartStream($multipartContents);

            } elseif ($headers['Content-Type'] === 'application/json') {
                $httpBody = wp_json_encode($formParams);

            } else {
                // for HTTP post (form)
                $httpBody = ObjectSerializerPpl::buildQuery($formParams);
            }
        }

        // this endpoint requires Bearer (JWT) authentication (access token)
        if (!empty($this->config->getAccessToken())) {
            $headers['Authorization'] = 'Bearer ' . $this->config->getAccessToken();
        }

        $defaultHeaders = [];
        if ($this->config->getUserAgent()) {
            $defaultHeaders['User-Agent'] = $this->config->getUserAgent();
        }

        $headers = array_merge(
            $defaultHeaders,
            $headerParams,
            $headers
        );

        $query = ObjectSerializerPpl::buildQuery($queryParams);
        return new Request(
            'GET',
            $this->config->getHost() . $resourcePath . ($query ? "?{$query}" : ''),
            $headers,
            $httpBody
        );
    }

    /**
     * Operation codelistServicePriceLimitGet
     *
     * Metoda pro získání minimálních a maximálních hodnot u služeb
     *
     * @param  int $limit limit (required)
     * @param  int $offset offset (required)
     * @param  string $service Service code (optional)
     * @param  string $currency Currency code (optional)
     * @param  string $country Country code (optional)
     * @param  string $product Product code (optional)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistServicePriceLimitModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel
     */
    public function codelistServicePriceLimitGet($limit, $offset, $service = null, $currency = null, $country = null, $product = null, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        list($response) = $this->codelistServicePriceLimitGetWithHttpInfo($limit, $offset, $service, $currency, $country, $product, $accept_language, $x_correlation_id, $x_log_level);
        return $response;
    }

    /**
     * Operation codelistServicePriceLimitGetWithHttpInfo
     *
     * Metoda pro získání minimálních a maximálních hodnot u služeb
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $service Service code (optional)
     * @param  string $currency Currency code (optional)
     * @param  string $country Country code (optional)
     * @param  string $product Product code (optional)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return array of \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistServicePriceLimitModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel, HTTP status code, HTTP response headers (array of strings)
     */
    public function codelistServicePriceLimitGetWithHttpInfo($limit, $offset, $service = null, $currency = null, $country = null, $product = null, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $request = $this->codelistServicePriceLimitGetRequest($limit, $offset, $service, $currency, $country, $product, $accept_language, $x_correlation_id, $x_log_level);

        try {
            $options = $this->createHttpClientOption();
            try {
                $response = $this->client->send($request, $options);
            } catch (RequestException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    $e->getResponse() ? $e->getResponse()->getHeaders() : null,
                    $e->getResponse() ? (string) $e->getResponse()->getBody() : null
                );
            } catch (ConnectException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    null,
                    null
                );
            }

            $statusCode = $response->getStatusCode();

            if ($statusCode < 200 || $statusCode > 299) {
                throw new ApiException(
                    sprintf(
                        '[%d] Error connecting to the API (%s)',
                        $statusCode,
                        (string) $request->getUri()
                    ),
                    $statusCode,
                    $response->getHeaders(),
                    (string) $response->getBody()
                );
            }

            switch($statusCode) {
                case 200:
                    if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistServicePriceLimitModel[]' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistServicePriceLimitModel[]' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistServicePriceLimitModel[]', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 400:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 500:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 503:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
            }

            $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistServicePriceLimitModel[]';
            if ($returnType === '\SplFileObject') {
                $content = $response->getBody(); //stream goes to serializer
            } else {
                $content = (string) $response->getBody();
                if ($returnType !== 'string') {
                    $content = json_decode($content);
                }
            }

            return [
                ObjectSerializerPpl::deserialize($content, $returnType, []),
                $response->getStatusCode(),
                $response->getHeaders()
            ];

        } catch (ApiException $e) {
            switch ($e->getCode()) {
                case 200:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistServicePriceLimitModel[]',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 400:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 500:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 503:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
            }
            throw $e;
        }
    }

    /**
     * Operation codelistServicePriceLimitGetAsync
     *
     * Metoda pro získání minimálních a maximálních hodnot u služeb
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $service Service code (optional)
     * @param  string $currency Currency code (optional)
     * @param  string $country Country code (optional)
     * @param  string $product Product code (optional)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistServicePriceLimitGetAsync($limit, $offset, $service = null, $currency = null, $country = null, $product = null, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        return $this->codelistServicePriceLimitGetAsyncWithHttpInfo($limit, $offset, $service, $currency, $country, $product, $accept_language, $x_correlation_id, $x_log_level)
            ->then(
                function ($response) {
                    return $response[0];
                }
            );
    }

    /**
     * Operation codelistServicePriceLimitGetAsyncWithHttpInfo
     *
     * Metoda pro získání minimálních a maximálních hodnot u služeb
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $service Service code (optional)
     * @param  string $currency Currency code (optional)
     * @param  string $country Country code (optional)
     * @param  string $product Product code (optional)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistServicePriceLimitGetAsyncWithHttpInfo($limit, $offset, $service = null, $currency = null, $country = null, $product = null, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistServicePriceLimitModel[]';
        $request = $this->codelistServicePriceLimitGetRequest($limit, $offset, $service, $currency, $country, $product, $accept_language, $x_correlation_id, $x_log_level);

        return $this->client
            ->sendAsync($request, $this->createHttpClientOption())
            ->then(
                function ($response) use ($returnType) {
                    if ($returnType === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ($returnType !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, $returnType, []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                },
                function ($exception) {
                    $response = $exception->getResponse();
                    $statusCode = $response->getStatusCode();
                    throw new ApiException(
                        sprintf(
                            '[%d] Error connecting to the API (%s)',
                            $statusCode,
                            $exception->getRequest()->getUri()
                        ),
                        $statusCode,
                        $response->getHeaders(),
                        (string) $response->getBody()
                    );
                }
            );
    }

    /**
     * Create request for operation 'codelistServicePriceLimitGet'
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $service Service code (optional)
     * @param  string $currency Currency code (optional)
     * @param  string $country Country code (optional)
     * @param  string $product Product code (optional)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Psr7\Request
     */
    public function codelistServicePriceLimitGetRequest($limit, $offset, $service = null, $currency = null, $country = null, $product = null, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        // verify the required parameter 'limit' is set
        if ($limit === null || (is_array($limit) && count($limit) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $limit when calling codelistServicePriceLimitGet'
            );
        }
        if ($limit > 1000) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistServicePriceLimitGet, must be smaller than or equal to 1000.');
        }
        if ($limit < 1) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistServicePriceLimitGet, must be bigger than or equal to 1.');
        }

        // verify the required parameter 'offset' is set
        if ($offset === null || (is_array($offset) && count($offset) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $offset when calling codelistServicePriceLimitGet'
            );
        }
        if ($offset > 2147483647) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistServicePriceLimitGet, must be smaller than or equal to 2147483647.');
        }
        if ($offset < 0) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistServicePriceLimitGet, must be bigger than or equal to 0.');
        }


        $resourcePath = '/codelist/servicePriceLimit';
        $formParams = [];
        $queryParams = [];
        $headerParams = [];
        $httpBody = '';
        $multipart = false;

        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $service,
            'Service', // param base name
            'string', // openApiType
            'form', // style
            true, // explode
            false // required
        ) ?? []);
        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $currency,
            'Currency', // param base name
            'string', // openApiType
            'form', // style
            true, // explode
            false // required
        ) ?? []);
        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $country,
            'Country', // param base name
            'string', // openApiType
            'form', // style
            true, // explode
            false // required
        ) ?? []);
        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $product,
            'Product', // param base name
            'string', // openApiType
            'form', // style
            true, // explode
            false // required
        ) ?? []);
        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $limit,
            'Limit', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);
        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $offset,
            'Offset', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);

        // header params
        if ($accept_language !== null) {
            $headerParams['Accept-Language'] = ObjectSerializerPpl::toHeaderValue($accept_language);
        }
        // header params
        if ($x_correlation_id !== null) {
            $headerParams['X-Correlation-ID'] = ObjectSerializerPpl::toHeaderValue($x_correlation_id);
        }
        // header params
        if ($x_log_level !== null) {
            $headerParams['X-LogLevel'] = ObjectSerializerPpl::toHeaderValue($x_log_level);
        }



        if ($multipart) {
            $headers = $this->headerSelector->selectHeadersForMultipart(
                ['application/json', 'text/json', 'application/problem+json']
            );
        } else {
            $headers = $this->headerSelector->selectHeaders(
                ['application/json', 'text/json', 'application/problem+json'],
                []
            );
        }

        // for model (json/xml)
        if (count($formParams) > 0) {
            if ($multipart) {
                $multipartContents = [];
                foreach ($formParams as $formParamName => $formParamValue) {
                    $formParamValueItems = is_array($formParamValue) ? $formParamValue : [$formParamValue];
                    foreach ($formParamValueItems as $formParamValueItem) {
                        $multipartContents[] = [
                            'name' => $formParamName,
                            'contents' => $formParamValueItem
                        ];
                    }
                }
                // for HTTP post (form)
                $httpBody = new MultipartStream($multipartContents);

            } elseif ($headers['Content-Type'] === 'application/json') {
                $httpBody = wp_json_encode($formParams);

            } else {
                // for HTTP post (form)
                $httpBody = ObjectSerializerPpl::buildQuery($formParams);
            }
        }

        // this endpoint requires Bearer (JWT) authentication (access token)
        if (!empty($this->config->getAccessToken())) {
            $headers['Authorization'] = 'Bearer ' . $this->config->getAccessToken();
        }

        $defaultHeaders = [];
        if ($this->config->getUserAgent()) {
            $defaultHeaders['User-Agent'] = $this->config->getUserAgent();
        }

        $headers = array_merge(
            $defaultHeaders,
            $headerParams,
            $headers
        );

        $query = ObjectSerializerPpl::buildQuery($queryParams);
        return new Request(
            'GET',
            $this->config->getHost() . $resourcePath . ($query ? "?{$query}" : ''),
            $headers,
            $httpBody
        );
    }

    /**
     * Operation codelistShipmentPhaseGet
     *
     * Fáze zásilky
     *
     * @param  int $limit limit (required)
     * @param  int $offset offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentPhaseModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel
     */
    public function codelistShipmentPhaseGet($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        list($response) = $this->codelistShipmentPhaseGetWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
        return $response;
    }

    /**
     * Operation codelistShipmentPhaseGetWithHttpInfo
     *
     * Fáze zásilky
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return array of \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentPhaseModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel, HTTP status code, HTTP response headers (array of strings)
     */
    public function codelistShipmentPhaseGetWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $request = $this->codelistShipmentPhaseGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        try {
            $options = $this->createHttpClientOption();
            try {
                $response = $this->client->send($request, $options);
            } catch (RequestException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    $e->getResponse() ? $e->getResponse()->getHeaders() : null,
                    $e->getResponse() ? (string) $e->getResponse()->getBody() : null
                );
            } catch (ConnectException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    null,
                    null
                );
            }

            $statusCode = $response->getStatusCode();

            if ($statusCode < 200 || $statusCode > 299) {
                throw new ApiException(
                    sprintf(
                        '[%d] Error connecting to the API (%s)',
                        $statusCode,
                        (string) $request->getUri()
                    ),
                    $statusCode,
                    $response->getHeaders(),
                    (string) $response->getBody()
                );
            }

            switch($statusCode) {
                case 200:
                    if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentPhaseModel[]' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentPhaseModel[]' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentPhaseModel[]', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 400:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 500:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 503:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
            }

            $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentPhaseModel[]';
            if ($returnType === '\SplFileObject') {
                $content = $response->getBody(); //stream goes to serializer
            } else {
                $content = (string) $response->getBody();
                if ($returnType !== 'string') {
                    $content = json_decode($content);
                }
            }

            return [
                ObjectSerializerPpl::deserialize($content, $returnType, []),
                $response->getStatusCode(),
                $response->getHeaders()
            ];

        } catch (ApiException $e) {
            switch ($e->getCode()) {
                case 200:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentPhaseModel[]',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 400:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 500:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 503:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
            }
            throw $e;
        }
    }

    /**
     * Operation codelistShipmentPhaseGetAsync
     *
     * Fáze zásilky
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistShipmentPhaseGetAsync($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        return $this->codelistShipmentPhaseGetAsyncWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level)
            ->then(
                function ($response) {
                    return $response[0];
                }
            );
    }

    /**
     * Operation codelistShipmentPhaseGetAsyncWithHttpInfo
     *
     * Fáze zásilky
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistShipmentPhaseGetAsyncWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistShipmentPhaseModel[]';
        $request = $this->codelistShipmentPhaseGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        return $this->client
            ->sendAsync($request, $this->createHttpClientOption())
            ->then(
                function ($response) use ($returnType) {
                    if ($returnType === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ($returnType !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, $returnType, []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                },
                function ($exception) {
                    $response = $exception->getResponse();
                    $statusCode = $response->getStatusCode();
                    throw new ApiException(
                        sprintf(
                            '[%d] Error connecting to the API (%s)',
                            $statusCode,
                            $exception->getRequest()->getUri()
                        ),
                        $statusCode,
                        $response->getHeaders(),
                        (string) $response->getBody()
                    );
                }
            );
    }

    /**
     * Create request for operation 'codelistShipmentPhaseGet'
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Psr7\Request
     */
    public function codelistShipmentPhaseGetRequest($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        // verify the required parameter 'limit' is set
        if ($limit === null || (is_array($limit) && count($limit) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $limit when calling codelistShipmentPhaseGet'
            );
        }
        if ($limit > 1000) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistShipmentPhaseGet, must be smaller than or equal to 1000.');
        }
        if ($limit < 1) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistShipmentPhaseGet, must be bigger than or equal to 1.');
        }

        // verify the required parameter 'offset' is set
        if ($offset === null || (is_array($offset) && count($offset) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $offset when calling codelistShipmentPhaseGet'
            );
        }
        if ($offset > 2147483647) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistShipmentPhaseGet, must be smaller than or equal to 2147483647.');
        }
        if ($offset < 0) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistShipmentPhaseGet, must be bigger than or equal to 0.');
        }


        $resourcePath = '/codelist/shipmentPhase';
        $formParams = [];
        $queryParams = [];
        $headerParams = [];
        $httpBody = '';
        $multipart = false;

        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $limit,
            'Limit', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);
        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $offset,
            'Offset', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);

        // header params
        if ($accept_language !== null) {
            $headerParams['Accept-Language'] = ObjectSerializerPpl::toHeaderValue($accept_language);
        }
        // header params
        if ($x_correlation_id !== null) {
            $headerParams['X-Correlation-ID'] = ObjectSerializerPpl::toHeaderValue($x_correlation_id);
        }
        // header params
        if ($x_log_level !== null) {
            $headerParams['X-LogLevel'] = ObjectSerializerPpl::toHeaderValue($x_log_level);
        }



        if ($multipart) {
            $headers = $this->headerSelector->selectHeadersForMultipart(
                ['application/json', 'text/json', 'application/problem+json']
            );
        } else {
            $headers = $this->headerSelector->selectHeaders(
                ['application/json', 'text/json', 'application/problem+json'],
                []
            );
        }

        // for model (json/xml)
        if (count($formParams) > 0) {
            if ($multipart) {
                $multipartContents = [];
                foreach ($formParams as $formParamName => $formParamValue) {
                    $formParamValueItems = is_array($formParamValue) ? $formParamValue : [$formParamValue];
                    foreach ($formParamValueItems as $formParamValueItem) {
                        $multipartContents[] = [
                            'name' => $formParamName,
                            'contents' => $formParamValueItem
                        ];
                    }
                }
                // for HTTP post (form)
                $httpBody = new MultipartStream($multipartContents);

            } elseif ($headers['Content-Type'] === 'application/json') {
                $httpBody = wp_json_encode($formParams);

            } else {
                // for HTTP post (form)
                $httpBody = ObjectSerializerPpl::buildQuery($formParams);
            }
        }

        // this endpoint requires Bearer (JWT) authentication (access token)
        if (!empty($this->config->getAccessToken())) {
            $headers['Authorization'] = 'Bearer ' . $this->config->getAccessToken();
        }

        $defaultHeaders = [];
        if ($this->config->getUserAgent()) {
            $defaultHeaders['User-Agent'] = $this->config->getUserAgent();
        }

        $headers = array_merge(
            $defaultHeaders,
            $headerParams,
            $headers
        );

        $query = ObjectSerializerPpl::buildQuery($queryParams);
        return new Request(
            'GET',
            $this->config->getHost() . $resourcePath . ($query ? "?{$query}" : ''),
            $headers,
            $httpBody
        );
    }

    /**
     * Operation codelistStatusGet
     *
     * Statusy zásilky /shipment
     *
     * @param  int $limit limit (required)
     * @param  int $offset offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistStatusModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel
     */
    public function codelistStatusGet($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        list($response) = $this->codelistStatusGetWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
        return $response;
    }

    /**
     * Operation codelistStatusGetWithHttpInfo
     *
     * Statusy zásilky /shipment
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return array of \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistStatusModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel, HTTP status code, HTTP response headers (array of strings)
     */
    public function codelistStatusGetWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $request = $this->codelistStatusGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        try {
            $options = $this->createHttpClientOption();
            try {
                $response = $this->client->send($request, $options);
            } catch (RequestException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    $e->getResponse() ? $e->getResponse()->getHeaders() : null,
                    $e->getResponse() ? (string) $e->getResponse()->getBody() : null
                );
            } catch (ConnectException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    null,
                    null
                );
            }

            $statusCode = $response->getStatusCode();

            if ($statusCode < 200 || $statusCode > 299) {
                throw new ApiException(
                    sprintf(
                        '[%d] Error connecting to the API (%s)',
                        $statusCode,
                        (string) $request->getUri()
                    ),
                    $statusCode,
                    $response->getHeaders(),
                    (string) $response->getBody()
                );
            }

            switch($statusCode) {
                case 200:
                    if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistStatusModel[]' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistStatusModel[]' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistStatusModel[]', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 400:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 500:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 503:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
            }

            $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistStatusModel[]';
            if ($returnType === '\SplFileObject') {
                $content = $response->getBody(); //stream goes to serializer
            } else {
                $content = (string) $response->getBody();
                if ($returnType !== 'string') {
                    $content = json_decode($content);
                }
            }

            return [
                ObjectSerializerPpl::deserialize($content, $returnType, []),
                $response->getStatusCode(),
                $response->getHeaders()
            ];

        } catch (ApiException $e) {
            switch ($e->getCode()) {
                case 200:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistStatusModel[]',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 400:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 500:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 503:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
            }
            throw $e;
        }
    }

    /**
     * Operation codelistStatusGetAsync
     *
     * Statusy zásilky /shipment
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistStatusGetAsync($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        return $this->codelistStatusGetAsyncWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level)
            ->then(
                function ($response) {
                    return $response[0];
                }
            );
    }

    /**
     * Operation codelistStatusGetAsyncWithHttpInfo
     *
     * Statusy zásilky /shipment
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistStatusGetAsyncWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistStatusModel[]';
        $request = $this->codelistStatusGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        return $this->client
            ->sendAsync($request, $this->createHttpClientOption())
            ->then(
                function ($response) use ($returnType) {
                    if ($returnType === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ($returnType !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, $returnType, []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                },
                function ($exception) {
                    $response = $exception->getResponse();
                    $statusCode = $response->getStatusCode();
                    throw new ApiException(
                        sprintf(
                            '[%d] Error connecting to the API (%s)',
                            $statusCode,
                            $exception->getRequest()->getUri()
                        ),
                        $statusCode,
                        $response->getHeaders(),
                        (string) $response->getBody()
                    );
                }
            );
    }

    /**
     * Create request for operation 'codelistStatusGet'
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Psr7\Request
     */
    public function codelistStatusGetRequest($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        // verify the required parameter 'limit' is set
        if ($limit === null || (is_array($limit) && count($limit) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $limit when calling codelistStatusGet'
            );
        }
        if ($limit > 1000) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistStatusGet, must be smaller than or equal to 1000.');
        }
        if ($limit < 1) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistStatusGet, must be bigger than or equal to 1.');
        }

        // verify the required parameter 'offset' is set
        if ($offset === null || (is_array($offset) && count($offset) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $offset when calling codelistStatusGet'
            );
        }
        if ($offset > 2147483647) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistStatusGet, must be smaller than or equal to 2147483647.');
        }
        if ($offset < 0) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistStatusGet, must be bigger than or equal to 0.');
        }


        $resourcePath = '/codelist/status';
        $formParams = [];
        $queryParams = [];
        $headerParams = [];
        $httpBody = '';
        $multipart = false;

        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $limit,
            'Limit', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);
        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $offset,
            'Offset', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);

        // header params
        if ($accept_language !== null) {
            $headerParams['Accept-Language'] = ObjectSerializerPpl::toHeaderValue($accept_language);
        }
        // header params
        if ($x_correlation_id !== null) {
            $headerParams['X-Correlation-ID'] = ObjectSerializerPpl::toHeaderValue($x_correlation_id);
        }
        // header params
        if ($x_log_level !== null) {
            $headerParams['X-LogLevel'] = ObjectSerializerPpl::toHeaderValue($x_log_level);
        }



        if ($multipart) {
            $headers = $this->headerSelector->selectHeadersForMultipart(
                ['application/json', 'text/json', 'application/problem+json']
            );
        } else {
            $headers = $this->headerSelector->selectHeaders(
                ['application/json', 'text/json', 'application/problem+json'],
                []
            );
        }

        // for model (json/xml)
        if (count($formParams) > 0) {
            if ($multipart) {
                $multipartContents = [];
                foreach ($formParams as $formParamName => $formParamValue) {
                    $formParamValueItems = is_array($formParamValue) ? $formParamValue : [$formParamValue];
                    foreach ($formParamValueItems as $formParamValueItem) {
                        $multipartContents[] = [
                            'name' => $formParamName,
                            'contents' => $formParamValueItem
                        ];
                    }
                }
                // for HTTP post (form)
                $httpBody = new MultipartStream($multipartContents);

            } elseif ($headers['Content-Type'] === 'application/json') {
                $httpBody = wp_json_encode($formParams);

            } else {
                // for HTTP post (form)
                $httpBody = ObjectSerializerPpl::buildQuery($formParams);
            }
        }

        // this endpoint requires Bearer (JWT) authentication (access token)
        if (!empty($this->config->getAccessToken())) {
            $headers['Authorization'] = 'Bearer ' . $this->config->getAccessToken();
        }

        $defaultHeaders = [];
        if ($this->config->getUserAgent()) {
            $defaultHeaders['User-Agent'] = $this->config->getUserAgent();
        }

        $headers = array_merge(
            $defaultHeaders,
            $headerParams,
            $headers
        );

        $query = ObjectSerializerPpl::buildQuery($queryParams);
        return new Request(
            'GET',
            $this->config->getHost() . $resourcePath . ($query ? "?{$query}" : ''),
            $headers,
            $httpBody
        );
    }

    /**
     * Operation codelistValidationMessageGet
     *
     * Chybové hlášení.
     *
     * @param  int $limit limit (required)
     * @param  int $offset offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistValidationMessageModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel
     */
    public function codelistValidationMessageGet($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        list($response) = $this->codelistValidationMessageGetWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);
        return $response;
    }

    /**
     * Operation codelistValidationMessageGetWithHttpInfo
     *
     * Chybové hlášení.
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \PPLCZCPL\ApiException on non-2xx response
     * @throws \InvalidArgumentException
     * @return array of \PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistValidationMessageModel[]|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel|\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel, HTTP status code, HTTP response headers (array of strings)
     */
    public function codelistValidationMessageGetWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $request = $this->codelistValidationMessageGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        try {
            $options = $this->createHttpClientOption();
            try {
                $response = $this->client->send($request, $options);
            } catch (RequestException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    $e->getResponse() ? $e->getResponse()->getHeaders() : null,
                    $e->getResponse() ? (string) $e->getResponse()->getBody() : null
                );
            } catch (ConnectException $e) {
                throw new ApiException(
                    "[{$e->getCode()}] {$e->getMessage()}",
                    (int) $e->getCode(),
                    null,
                    null
                );
            }

            $statusCode = $response->getStatusCode();

            if ($statusCode < 200 || $statusCode > 299) {
                throw new ApiException(
                    sprintf(
                        '[%d] Error connecting to the API (%s)',
                        $statusCode,
                        (string) $request->getUri()
                    ),
                    $statusCode,
                    $response->getHeaders(),
                    (string) $response->getBody()
                );
            }

            switch($statusCode) {
                case 200:
                    if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistValidationMessageModel[]' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistValidationMessageModel[]' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistValidationMessageModel[]', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 400:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 500:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                case 503:
                    if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ('\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel' !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel', []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
            }

            $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistValidationMessageModel[]';
            if ($returnType === '\SplFileObject') {
                $content = $response->getBody(); //stream goes to serializer
            } else {
                $content = (string) $response->getBody();
                if ($returnType !== 'string') {
                    $content = json_decode($content);
                }
            }

            return [
                ObjectSerializerPpl::deserialize($content, $returnType, []),
                $response->getStatusCode(),
                $response->getHeaders()
            ];

        } catch (ApiException $e) {
            switch ($e->getCode()) {
                case 200:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistValidationMessageModel[]',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 400:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 500:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
                case 503:
                    $data = ObjectSerializerPpl::deserialize(
                        $e->getResponseBody(),
                        '\PPLCZCPL\Model\EpsApiInfrastructureWebApiModelProblemJsonModel',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                    break;
            }
            throw $e;
        }
    }

    /**
     * Operation codelistValidationMessageGetAsync
     *
     * Chybové hlášení.
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistValidationMessageGetAsync($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        return $this->codelistValidationMessageGetAsyncWithHttpInfo($limit, $offset, $accept_language, $x_correlation_id, $x_log_level)
            ->then(
                function ($response) {
                    return $response[0];
                }
            );
    }

    /**
     * Operation codelistValidationMessageGetAsyncWithHttpInfo
     *
     * Chybové hlášení.
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Promise\PromiseInterface
     */
    public function codelistValidationMessageGetAsyncWithHttpInfo($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        $returnType = '\PPLCZCPL\Model\EpsApiMyApi2WebModelsCodelistValidationMessageModel[]';
        $request = $this->codelistValidationMessageGetRequest($limit, $offset, $accept_language, $x_correlation_id, $x_log_level);

        return $this->client
            ->sendAsync($request, $this->createHttpClientOption())
            ->then(
                function ($response) use ($returnType) {
                    if ($returnType === '\SplFileObject') {
                        $content = $response->getBody(); //stream goes to serializer
                    } else {
                        $content = (string) $response->getBody();
                        if ($returnType !== 'string') {
                            $content = json_decode($content);
                        }
                    }

                    return [
                        ObjectSerializerPpl::deserialize($content, $returnType, []),
                        $response->getStatusCode(),
                        $response->getHeaders()
                    ];
                },
                function ($exception) {
                    $response = $exception->getResponse();
                    $statusCode = $response->getStatusCode();
                    throw new ApiException(
                        sprintf(
                            '[%d] Error connecting to the API (%s)',
                            $statusCode,
                            $exception->getRequest()->getUri()
                        ),
                        $statusCode,
                        $response->getHeaders(),
                        (string) $response->getBody()
                    );
                }
            );
    }

    /**
     * Create request for operation 'codelistValidationMessageGet'
     *
     * @param  int $limit (required)
     * @param  int $offset (required)
     * @param  string $accept_language Language specification, default language: cs-CZ (optional)
     * @param  string $x_correlation_id Correlation Id of request (optional)
     * @param  XLogLevelSchema $x_log_level The forced log level (optional)
     *
     * @throws \InvalidArgumentException
     * @return \PPLCZVendor\GuzzleHttp\Psr7\Request
     */
    public function codelistValidationMessageGetRequest($limit, $offset, $accept_language = null, $x_correlation_id = null, $x_log_level = null)
    {
        // verify the required parameter 'limit' is set
        if ($limit === null || (is_array($limit) && count($limit) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $limit when calling codelistValidationMessageGet'
            );
        }
        if ($limit > 1000) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistValidationMessageGet, must be smaller than or equal to 1000.');
        }
        if ($limit < 1) {
            throw new \InvalidArgumentException('invalid value for "$limit" when calling CodelistApi.codelistValidationMessageGet, must be bigger than or equal to 1.');
        }

        // verify the required parameter 'offset' is set
        if ($offset === null || (is_array($offset) && count($offset) === 0)) {
            throw new \InvalidArgumentException(
                'Missing the required parameter $offset when calling codelistValidationMessageGet'
            );
        }
        if ($offset > 2147483647) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistValidationMessageGet, must be smaller than or equal to 2147483647.');
        }
        if ($offset < 0) {
            throw new \InvalidArgumentException('invalid value for "$offset" when calling CodelistApi.codelistValidationMessageGet, must be bigger than or equal to 0.');
        }


        $resourcePath = '/codelist/validationMessage';
        $formParams = [];
        $queryParams = [];
        $headerParams = [];
        $httpBody = '';
        $multipart = false;

        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $limit,
            'Limit', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);
        // query params
        $queryParams = array_merge($queryParams, ObjectSerializerPpl::toQueryValue(
            $offset,
            'Offset', // param base name
            'integer', // openApiType
            'form', // style
            true, // explode
            true // required
        ) ?? []);

        // header params
        if ($accept_language !== null) {
            $headerParams['Accept-Language'] = ObjectSerializerPpl::toHeaderValue($accept_language);
        }
        // header params
        if ($x_correlation_id !== null) {
            $headerParams['X-Correlation-ID'] = ObjectSerializerPpl::toHeaderValue($x_correlation_id);
        }
        // header params
        if ($x_log_level !== null) {
            $headerParams['X-LogLevel'] = ObjectSerializerPpl::toHeaderValue($x_log_level);
        }



        if ($multipart) {
            $headers = $this->headerSelector->selectHeadersForMultipart(
                ['application/json', 'text/json', 'application/problem+json']
            );
        } else {
            $headers = $this->headerSelector->selectHeaders(
                ['application/json', 'text/json', 'application/problem+json'],
                []
            );
        }

        // for model (json/xml)
        if (count($formParams) > 0) {
            if ($multipart) {
                $multipartContents = [];
                foreach ($formParams as $formParamName => $formParamValue) {
                    $formParamValueItems = is_array($formParamValue) ? $formParamValue : [$formParamValue];
                    foreach ($formParamValueItems as $formParamValueItem) {
                        $multipartContents[] = [
                            'name' => $formParamName,
                            'contents' => $formParamValueItem
                        ];
                    }
                }
                // for HTTP post (form)
                $httpBody = new MultipartStream($multipartContents);

            } elseif ($headers['Content-Type'] === 'application/json') {
                $httpBody = wp_json_encode($formParams);

            } else {
                // for HTTP post (form)
                $httpBody = ObjectSerializerPpl::buildQuery($formParams);
            }
        }

        // this endpoint requires Bearer (JWT) authentication (access token)
        if (!empty($this->config->getAccessToken())) {
            $headers['Authorization'] = 'Bearer ' . $this->config->getAccessToken();
        }

        $defaultHeaders = [];
        if ($this->config->getUserAgent()) {
            $defaultHeaders['User-Agent'] = $this->config->getUserAgent();
        }

        $headers = array_merge(
            $defaultHeaders,
            $headerParams,
            $headers
        );

        $query = ObjectSerializerPpl::buildQuery($queryParams);
        return new Request(
            'GET',
            $this->config->getHost() . $resourcePath . ($query ? "?{$query}" : ''),
            $headers,
            $httpBody
        );
    }

    /**
     * Create http client option
     *
     * @throws \RuntimeException on file opening failure
     * @return array of http client options
     */
    protected function createHttpClientOption()
    {
        $options = [];
        if ($this->config->getDebug()) {
            $options[RequestOptions::DEBUG] = fopen($this->config->getDebugFile(), 'a');
            if (!$options[RequestOptions::DEBUG]) {
                throw new \RuntimeException('Failed to open the debug file: ' . $this->config->getDebugFile());
            }
        }

        return $options;
    }
}
