<?php 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            

/**
 * EpsApiMyApi2WebModelsCustomerAccountModel
 *
 * PHP version 7.4
 *
 * @category Class
 * @package  PPLCZCPL
 * @author   OpenAPI Generator team
 * @link     https://openapi-generator.tech
 */

/**
 * CPL
 *
 * **Changelog**    * 2024-08-22 - SPRJ-13791 - validace PRTE / PRBC externích čísel - nelze použít najednou    - /shipment/batch    * 2024-07-01 - SPRJ-13838 - přidání    - /customer/address    * 2023-11-23 - SPRJ-12703 - CPL - /shipment - timestamp    - /shipment - Rozšíření výstupu o LastUpdateDate.    * 2023-07-13 - SPRJ-11888 - přidání    - /codelist/status - číselník statusů    * 2023-07-13 - SPRJ-11953 - přidání    - /order/cancel - storno objednávky
 *
 * The version of the OpenAPI document: v1
 * Generated by: https://openapi-generator.tech
 * OpenAPI Generator version: 6.0.1
 */

/**
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */

namespace PPLCZCPL\Model;

use \ArrayAccess;
use \PPLCZCPL\ObjectSerializer;

/**
 * EpsApiMyApi2WebModelsCustomerAccountModel Class Doc Comment
 *
 * @category Class
 * @description Account model
 * @package  PPLCZCPL
 * @author   OpenAPI Generator team
 * @link     https://openapi-generator.tech
 * @implements \ArrayAccess<string, mixed>
 */
class EpsApiMyApi2WebModelsCustomerAccountModel implements ModelInterface, ArrayAccess, \JsonSerializable
{
    public const DISCRIMINATOR = null;

    /**
      * The original name of the model.
      *
      * @var string
      */
    protected static $openAPIModelName = 'Eps.Api.MyApi2.Web.Models.Customer.AccountModel';

    /**
      * Array of property to type mappings. Used for (de)serialization
      *
      * @var string[]
      */
    protected static $openAPITypes = [
        'bank_code' => 'string',
        'country' => 'string',
        'currency' => 'string',
        'swift' => 'string'
    ];

    /**
      * Array of property to format mappings. Used for (de)serialization
      *
      * @var string[]
      * @phpstan-var array<string, string|null>
      * @psalm-var array<string, string|null>
      */
    protected static $openAPIFormats = [
        'bank_code' => null,
        'country' => null,
        'currency' => null,
        'swift' => null
    ];

    /**
     * Array of property to type mappings. Used for (de)serialization
     *
     * @return array
     */
    public static function openAPITypes()
    {
        return self::$openAPITypes;
    }

    /**
     * Array of property to format mappings. Used for (de)serialization
     *
     * @return array
     */
    public static function openAPIFormats()
    {
        return self::$openAPIFormats;
    }

    /**
     * Array of attributes where the key is the local name,
     * and the value is the original name
     *
     * @var string[]
     */
    protected static $attributeMap = [
        'bank_code' => 'bankCode',
        'country' => 'country',
        'currency' => 'currency',
        'swift' => 'swift'
    ];

    /**
     * Array of attributes to setter functions (for deserialization of responses)
     *
     * @var string[]
     */
    protected static $setters = [
        'bank_code' => 'setBankCode',
        'country' => 'setCountry',
        'currency' => 'setCurrency',
        'swift' => 'setSwift'
    ];

    /**
     * Array of attributes to getter functions (for serialization of requests)
     *
     * @var string[]
     */
    protected static $getters = [
        'bank_code' => 'getBankCode',
        'country' => 'getCountry',
        'currency' => 'getCurrency',
        'swift' => 'getSwift'
    ];

    /**
     * Array of attributes where the key is the local name,
     * and the value is the original name
     *
     * @return array
     */
    public static function attributeMap()
    {
        return self::$attributeMap;
    }

    /**
     * Array of attributes to setter functions (for deserialization of responses)
     *
     * @return array
     */
    public static function setters()
    {
        return self::$setters;
    }

    /**
     * Array of attributes to getter functions (for serialization of requests)
     *
     * @return array
     */
    public static function getters()
    {
        return self::$getters;
    }

    /**
     * The original name of the model.
     *
     * @return string
     */
    public function getModelName()
    {
        return self::$openAPIModelName;
    }


    /**
     * Associative array for storing property values
     *
     * @var mixed[]
     */
    protected $container = [];

    /**
     * Constructor
     *
     * @param mixed[] $data Associated array of property values
     *                      initializing the model
     */
    public function __construct(array $data = null)
    {
        $this->container['bank_code'] = $data['bank_code'] ?? null;
        $this->container['country'] = $data['country'] ?? null;
        $this->container['currency'] = $data['currency'] ?? null;
        $this->container['swift'] = $data['swift'] ?? null;
    }

    /**
     * Show all the invalid properties with reasons.
     *
     * @return array invalid properties with reasons
     */
    public function listInvalidProperties()
    {
        $invalidProperties = [];

        if (!is_null($this->container['bank_code']) && (mb_strlen($this->container['bank_code']) > 4)) {
            $invalidProperties[] = "invalid value for 'bank_code', the character length must be smaller than or equal to 4.";
        }

        if ($this->container['country'] === null) {
            $invalidProperties[] = "'country' can't be null";
        }
        if ((mb_strlen($this->container['country']) < 2)) {
            $invalidProperties[] = "invalid value for 'country', the character length must be bigger than or equal to 2.";
        }

        if ($this->container['currency'] === null) {
            $invalidProperties[] = "'currency' can't be null";
        }
        if ((mb_strlen($this->container['currency']) < 3)) {
            $invalidProperties[] = "invalid value for 'currency', the character length must be bigger than or equal to 3.";
        }

        if (!is_null($this->container['swift']) && (mb_strlen($this->container['swift']) > 50)) {
            $invalidProperties[] = "invalid value for 'swift', the character length must be smaller than or equal to 50.";
        }

        return $invalidProperties;
    }

    /**
     * Validate all the properties in the model
     * return true if all passed
     *
     * @return bool True if all properties are valid
     */
    public function valid()
    {
        return count($this->listInvalidProperties()) === 0;
    }


    /**
     * Gets bank_code
     *
     * @return string|null
     */
    public function getBankCode()
    {
        return $this->container['bank_code'];
    }

    /**
     * Sets bank_code
     *
     * @param string|null $bank_code Bank code
     *
     * @return self
     */
    public function setBankCode($bank_code)
    {
        if (!is_null($bank_code) && (mb_strlen($bank_code) > 4)) {
            throw new \InvalidArgumentException('invalid length for $bank_code when calling EpsApiMyApi2WebModelsCustomerAccountModel., must be smaller than or equal to 4.');
        }

        $this->container['bank_code'] = $bank_code;

        return $this;
    }

    /**
     * Gets country
     *
     * @return string
     */
    public function getCountry()
    {
        return $this->container['country'];
    }

    /**
     * Sets country
     *
     * @param string $country Country
     *
     * @return self
     */
    public function setCountry($country)
    {

        if ((mb_strlen($country) < 2)) {
            throw new \InvalidArgumentException('invalid length for $country when calling EpsApiMyApi2WebModelsCustomerAccountModel., must be bigger than or equal to 2.');
        }

        $this->container['country'] = $country;

        return $this;
    }

    /**
     * Gets currency
     *
     * @return string
     */
    public function getCurrency()
    {
        return $this->container['currency'];
    }

    /**
     * Sets currency
     *
     * @param string $currency Currency
     *
     * @return self
     */
    public function setCurrency($currency)
    {

        if ((mb_strlen($currency) < 3)) {
            throw new \InvalidArgumentException('invalid length for $currency when calling EpsApiMyApi2WebModelsCustomerAccountModel., must be bigger than or equal to 3.');
        }

        $this->container['currency'] = $currency;

        return $this;
    }

    /**
     * Gets swift
     *
     * @return string|null
     */
    public function getSwift()
    {
        return $this->container['swift'];
    }

    /**
     * Sets swift
     *
     * @param string|null $swift Swift
     *
     * @return self
     */
    public function setSwift($swift)
    {
        if (!is_null($swift) && (mb_strlen($swift) > 50)) {
            throw new \InvalidArgumentException('invalid length for $swift when calling EpsApiMyApi2WebModelsCustomerAccountModel., must be smaller than or equal to 50.');
        }

        $this->container['swift'] = $swift;

        return $this;
    }
    /**
     * Returns true if offset exists. False otherwise.
     *
     * @param integer $offset Offset
     *
     * @return boolean
     */
    public function offsetExists($offset): bool
    {
        return isset($this->container[$offset]);
    }

    /**
     * Gets offset.
     *
     * @param integer $offset Offset
     *
     * @return mixed|null
     */
    #[\ReturnTypeWillChange]
    public function offsetGet($offset)
    {
        return $this->container[$offset] ?? null;
    }

    /**
     * Sets value based on offset.
     *
     * @param int|null $offset Offset
     * @param mixed    $value  Value to be set
     *
     * @return void
     */
    public function offsetSet($offset, $value): void
    {
        if (is_null($offset)) {
            $this->container[] = $value;
        } else {
            $this->container[$offset] = $value;
        }
    }

    /**
     * Unsets offset.
     *
     * @param integer $offset Offset
     *
     * @return void
     */
    public function offsetUnset($offset): void
    {
        unset($this->container[$offset]);
    }

    /**
     * Serializes the object to a value that can be serialized natively by json_encode().
     * @link https://www.php.net/manual/en/jsonserializable.jsonserialize.php
     *
     * @return mixed Returns data which can be serialized by json_encode(), which is a value
     * of any type other than a resource.
     */
    #[\ReturnTypeWillChange]
    public function jsonSerialize()
    {
       return ObjectSerializerPpl::sanitizeForSerialization($this);
    }

    /**
     * Gets the string presentation of the object
     *
     * @return string
     */
    public function __toString()
    {
        return json_encode(
            ObjectSerializerPpl::sanitizeForSerialization($this),
            JSON_PRETTY_PRINT
        );
    }

    /**
     * Gets a header-safe presentation of the object
     *
     * @return string
     */
    public function toHeaderValue()
    {
        return json_encode(ObjectSerializerPpl::sanitizeForSerialization($this));
    }
}


