<?php 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            
 
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fclose
// phpcs:ignoreFile WordPress.WP.AlternativeFunctions.file_system_operations_fopen
// phpcs:ignoreFile WordPress.Security.EscapeOutput.ExceptionNotEscaped            

/**
 * EpsApiMyApi2WebModelsShipmentBatchShipmentModel
 *
 * PHP version 7.4
 *
 * @category Class
 * @package  PPLCZCPL
 * @author   OpenAPI Generator team
 * @link     https://openapi-generator.tech
 */

/**
 * CPL
 *
 * **Changelog**    * 2024-08-22 - SPRJ-13791 - validace PRTE / PRBC externích čísel - nelze použít najednou    - /shipment/batch    * 2024-07-01 - SPRJ-13838 - přidání    - /customer/address    * 2023-11-23 - SPRJ-12703 - CPL - /shipment - timestamp    - /shipment - Rozšíření výstupu o LastUpdateDate.    * 2023-07-13 - SPRJ-11888 - přidání    - /codelist/status - číselník statusů    * 2023-07-13 - SPRJ-11953 - přidání    - /order/cancel - storno objednávky
 *
 * The version of the OpenAPI document: v1
 * Generated by: https://openapi-generator.tech
 * OpenAPI Generator version: 6.0.1
 */

/**
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */

namespace PPLCZCPL\Model;

use \ArrayAccess;
use \PPLCZCPL\ObjectSerializer;

/**
 * EpsApiMyApi2WebModelsShipmentBatchShipmentModel Class Doc Comment
 *
 * @category Class
 * @description ShipmentModel
 * @package  PPLCZCPL
 * @author   OpenAPI Generator team
 * @link     https://openapi-generator.tech
 * @implements \ArrayAccess<string, mixed>
 */
class EpsApiMyApi2WebModelsShipmentBatchShipmentModel implements ModelInterface, ArrayAccess, \JsonSerializable
{
    public const DISCRIMINATOR = null;

    /**
      * The original name of the model.
      *
      * @var string
      */
    protected static $openAPIModelName = 'Eps.Api.MyApi2.Web.Models.ShipmentBatch.ShipmentModel';

    /**
      * Array of property to type mappings. Used for (de)serialization
      *
      * @var string[]
      */
    protected static $openAPITypes = [
        'reference_id' => 'string',
        'shipment_number' => 'string',
        'product_type' => 'string',
        'note' => 'string',
        'depot' => 'string',
        'age_check' => 'string',
        'integrator_id' => 'int',
        'shipment_set' => '\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelShipmentSet',
        'back_address' => '\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelBackAddress',
        'sender' => '\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelSender',
        'sender_mask' => '\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelSenderMask',
        'recipient' => '\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchRecipientAddressModel',
        'specific_delivery' => '\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelSpecificDelivery',
        'cash_on_delivery' => '\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelCashOnDelivery',
        'insurance' => '\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelInsurance',
        'external_numbers' => '\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchExternalNumberModel[]',
        'services' => '\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchServiceModel[]',
        'dormant' => '\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelDormant',
        'shipment_routing' => '\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelShipmentRouting',
        'direct_injection' => '\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelDirectInjection',
        'label_service' => '\PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelLabelService'
    ];

    /**
      * Array of property to format mappings. Used for (de)serialization
      *
      * @var string[]
      * @phpstan-var array<string, string|null>
      * @psalm-var array<string, string|null>
      */
    protected static $openAPIFormats = [
        'reference_id' => null,
        'shipment_number' => null,
        'product_type' => null,
        'note' => null,
        'depot' => null,
        'age_check' => null,
        'integrator_id' => 'int32',
        'shipment_set' => null,
        'back_address' => null,
        'sender' => null,
        'sender_mask' => null,
        'recipient' => null,
        'specific_delivery' => null,
        'cash_on_delivery' => null,
        'insurance' => null,
        'external_numbers' => null,
        'services' => null,
        'dormant' => null,
        'shipment_routing' => null,
        'direct_injection' => null,
        'label_service' => null
    ];

    /**
     * Array of property to type mappings. Used for (de)serialization
     *
     * @return array
     */
    public static function openAPITypes()
    {
        return self::$openAPITypes;
    }

    /**
     * Array of property to format mappings. Used for (de)serialization
     *
     * @return array
     */
    public static function openAPIFormats()
    {
        return self::$openAPIFormats;
    }

    /**
     * Array of attributes where the key is the local name,
     * and the value is the original name
     *
     * @var string[]
     */
    protected static $attributeMap = [
        'reference_id' => 'referenceId',
        'shipment_number' => 'shipmentNumber',
        'product_type' => 'productType',
        'note' => 'note',
        'depot' => 'depot',
        'age_check' => 'ageCheck',
        'integrator_id' => 'integratorId',
        'shipment_set' => 'shipmentSet',
        'back_address' => 'backAddress',
        'sender' => 'sender',
        'sender_mask' => 'senderMask',
        'recipient' => 'recipient',
        'specific_delivery' => 'specificDelivery',
        'cash_on_delivery' => 'cashOnDelivery',
        'insurance' => 'insurance',
        'external_numbers' => 'externalNumbers',
        'services' => 'services',
        'dormant' => 'dormant',
        'shipment_routing' => 'shipmentRouting',
        'direct_injection' => 'directInjection',
        'label_service' => 'labelService'
    ];

    /**
     * Array of attributes to setter functions (for deserialization of responses)
     *
     * @var string[]
     */
    protected static $setters = [
        'reference_id' => 'setReferenceId',
        'shipment_number' => 'setShipmentNumber',
        'product_type' => 'setProductType',
        'note' => 'setNote',
        'depot' => 'setDepot',
        'age_check' => 'setAgeCheck',
        'integrator_id' => 'setIntegratorId',
        'shipment_set' => 'setShipmentSet',
        'back_address' => 'setBackAddress',
        'sender' => 'setSender',
        'sender_mask' => 'setSenderMask',
        'recipient' => 'setRecipient',
        'specific_delivery' => 'setSpecificDelivery',
        'cash_on_delivery' => 'setCashOnDelivery',
        'insurance' => 'setInsurance',
        'external_numbers' => 'setExternalNumbers',
        'services' => 'setServices',
        'dormant' => 'setDormant',
        'shipment_routing' => 'setShipmentRouting',
        'direct_injection' => 'setDirectInjection',
        'label_service' => 'setLabelService'
    ];

    /**
     * Array of attributes to getter functions (for serialization of requests)
     *
     * @var string[]
     */
    protected static $getters = [
        'reference_id' => 'getReferenceId',
        'shipment_number' => 'getShipmentNumber',
        'product_type' => 'getProductType',
        'note' => 'getNote',
        'depot' => 'getDepot',
        'age_check' => 'getAgeCheck',
        'integrator_id' => 'getIntegratorId',
        'shipment_set' => 'getShipmentSet',
        'back_address' => 'getBackAddress',
        'sender' => 'getSender',
        'sender_mask' => 'getSenderMask',
        'recipient' => 'getRecipient',
        'specific_delivery' => 'getSpecificDelivery',
        'cash_on_delivery' => 'getCashOnDelivery',
        'insurance' => 'getInsurance',
        'external_numbers' => 'getExternalNumbers',
        'services' => 'getServices',
        'dormant' => 'getDormant',
        'shipment_routing' => 'getShipmentRouting',
        'direct_injection' => 'getDirectInjection',
        'label_service' => 'getLabelService'
    ];

    /**
     * Array of attributes where the key is the local name,
     * and the value is the original name
     *
     * @return array
     */
    public static function attributeMap()
    {
        return self::$attributeMap;
    }

    /**
     * Array of attributes to setter functions (for deserialization of responses)
     *
     * @return array
     */
    public static function setters()
    {
        return self::$setters;
    }

    /**
     * Array of attributes to getter functions (for serialization of requests)
     *
     * @return array
     */
    public static function getters()
    {
        return self::$getters;
    }

    /**
     * The original name of the model.
     *
     * @return string
     */
    public function getModelName()
    {
        return self::$openAPIModelName;
    }


    /**
     * Associative array for storing property values
     *
     * @var mixed[]
     */
    protected $container = [];

    /**
     * Constructor
     *
     * @param mixed[] $data Associated array of property values
     *                      initializing the model
     */
    public function __construct(array $data = null)
    {
        $this->container['reference_id'] = $data['reference_id'] ?? null;
        $this->container['shipment_number'] = $data['shipment_number'] ?? null;
        $this->container['product_type'] = $data['product_type'] ?? null;
        $this->container['note'] = $data['note'] ?? null;
        $this->container['depot'] = $data['depot'] ?? null;
        $this->container['age_check'] = $data['age_check'] ?? null;
        $this->container['integrator_id'] = $data['integrator_id'] ?? null;
        $this->container['shipment_set'] = $data['shipment_set'] ?? null;
        $this->container['back_address'] = $data['back_address'] ?? null;
        $this->container['sender'] = $data['sender'] ?? null;
        $this->container['sender_mask'] = $data['sender_mask'] ?? null;
        $this->container['recipient'] = $data['recipient'] ?? null;
        $this->container['specific_delivery'] = $data['specific_delivery'] ?? null;
        $this->container['cash_on_delivery'] = $data['cash_on_delivery'] ?? null;
        $this->container['insurance'] = $data['insurance'] ?? null;
        $this->container['external_numbers'] = $data['external_numbers'] ?? null;
        $this->container['services'] = $data['services'] ?? null;
        $this->container['dormant'] = $data['dormant'] ?? null;
        $this->container['shipment_routing'] = $data['shipment_routing'] ?? null;
        $this->container['direct_injection'] = $data['direct_injection'] ?? null;
        $this->container['label_service'] = $data['label_service'] ?? null;
    }

    /**
     * Show all the invalid properties with reasons.
     *
     * @return array invalid properties with reasons
     */
    public function listInvalidProperties()
    {
        $invalidProperties = [];

        if ($this->container['reference_id'] === null) {
            $invalidProperties[] = "'reference_id' can't be null";
        }
        if ((mb_strlen($this->container['reference_id']) > 128)) {
            $invalidProperties[] = "invalid value for 'reference_id', the character length must be smaller than or equal to 128.";
        }

        if ((mb_strlen($this->container['reference_id']) < 1)) {
            $invalidProperties[] = "invalid value for 'reference_id', the character length must be bigger than or equal to 1.";
        }

        if ($this->container['product_type'] === null) {
            $invalidProperties[] = "'product_type' can't be null";
        }
        if ((mb_strlen($this->container['product_type']) < 1)) {
            $invalidProperties[] = "invalid value for 'product_type', the character length must be bigger than or equal to 1.";
        }

        if (!is_null($this->container['integrator_id']) && ($this->container['integrator_id'] > 2147483647)) {
            $invalidProperties[] = "invalid value for 'integrator_id', must be smaller than or equal to 2147483647.";
        }

        if (!is_null($this->container['integrator_id']) && ($this->container['integrator_id'] < 1)) {
            $invalidProperties[] = "invalid value for 'integrator_id', must be bigger than or equal to 1.";
        }

        if ($this->container['recipient'] === null) {
            $invalidProperties[] = "'recipient' can't be null";
        }
        return $invalidProperties;
    }

    /**
     * Validate all the properties in the model
     * return true if all passed
     *
     * @return bool True if all properties are valid
     */
    public function valid()
    {
        return count($this->listInvalidProperties()) === 0;
    }


    /**
     * Gets reference_id
     *
     * @return string
     */
    public function getReferenceId()
    {
        return $this->container['reference_id'];
    }

    /**
     * Sets reference_id
     *
     * @param string $reference_id Jedinečná reference!
     *
     * @return self
     */
    public function setReferenceId($reference_id)
    {
        if ((mb_strlen($reference_id) > 128)) {
            throw new \InvalidArgumentException('invalid length for $reference_id when calling EpsApiMyApi2WebModelsShipmentBatchShipmentModel., must be smaller than or equal to 128.');
        }
        if ((mb_strlen($reference_id) < 1)) {
            throw new \InvalidArgumentException('invalid length for $reference_id when calling EpsApiMyApi2WebModelsShipmentBatchShipmentModel., must be bigger than or equal to 1.');
        }

        $this->container['reference_id'] = $reference_id;

        return $this;
    }

    /**
     * Gets shipment_number
     *
     * @return string|null
     */
    public function getShipmentNumber()
    {
        return $this->container['shipment_number'];
    }

    /**
     * Sets shipment_number
     *
     * @param string|null $shipment_number Číslo zásilky
     *
     * @return self
     */
    public function setShipmentNumber($shipment_number)
    {
        $this->container['shipment_number'] = $shipment_number;

        return $this;
    }

    /**
     * Gets product_type
     *
     * @return string
     */
    public function getProductType()
    {
        return $this->container['product_type'];
    }

    /**
     * Sets product_type
     *
     * @param string $product_type Typ produktu
     *
     * @return self
     */
    public function setProductType($product_type)
    {

        if ((mb_strlen($product_type) < 1)) {
            throw new \InvalidArgumentException('invalid length for $product_type when calling EpsApiMyApi2WebModelsShipmentBatchShipmentModel., must be bigger than or equal to 1.');
        }

        $this->container['product_type'] = $product_type;

        return $this;
    }

    /**
     * Gets note
     *
     * @return string|null
     */
    public function getNote()
    {
        return $this->container['note'];
    }

    /**
     * Sets note
     *
     * @param string|null $note Poznámka Délka: 300
     *
     * @return self
     */
    public function setNote($note)
    {
        $this->container['note'] = $note;

        return $this;
    }

    /**
     * Gets depot
     *
     * @return string|null
     */
    public function getDepot()
    {
        return $this->container['depot'];
    }

    /**
     * Sets depot
     *
     * @param string|null $depot Nepoužívat. Délka: 2
     *
     * @return self
     */
    public function setDepot($depot)
    {
        $this->container['depot'] = $depot;

        return $this;
    }

    /**
     * Gets age_check
     *
     * @return string|null
     */
    public function getAgeCheck()
    {
        return $this->container['age_check'];
    }

    /**
     * Sets age_check
     *
     * @param string|null $age_check Služba kontrola věku (15,18+)
     *
     * @return self
     */
    public function setAgeCheck($age_check)
    {
        $this->container['age_check'] = $age_check;

        return $this;
    }

    /**
     * Gets integrator_id
     *
     * @return int|null
     */
    public function getIntegratorId()
    {
        return $this->container['integrator_id'];
    }

    /**
     * Sets integrator_id
     *
     * @param int|null $integrator_id ID integrátora – pouze pro typ: integrátor
     *
     * @return self
     */
    public function setIntegratorId($integrator_id)
    {

        if (!is_null($integrator_id) && ($integrator_id > 2147483647)) {
            throw new \InvalidArgumentException('invalid value for $integrator_id when calling EpsApiMyApi2WebModelsShipmentBatchShipmentModel., must be smaller than or equal to 2147483647.');
        }
        if (!is_null($integrator_id) && ($integrator_id < 1)) {
            throw new \InvalidArgumentException('invalid value for $integrator_id when calling EpsApiMyApi2WebModelsShipmentBatchShipmentModel., must be bigger than or equal to 1.');
        }

        $this->container['integrator_id'] = $integrator_id;

        return $this;
    }

    /**
     * Gets shipment_set
     *
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelShipmentSet|null
     */
    public function getShipmentSet()
    {
        return $this->container['shipment_set'];
    }

    /**
     * Sets shipment_set
     *
     * @param \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelShipmentSet|null $shipment_set shipment_set
     *
     * @return self
     */
    public function setShipmentSet($shipment_set)
    {
        $this->container['shipment_set'] = $shipment_set;

        return $this;
    }

    /**
     * Gets back_address
     *
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelBackAddress|null
     */
    public function getBackAddress()
    {
        return $this->container['back_address'];
    }

    /**
     * Sets back_address
     *
     * @param \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelBackAddress|null $back_address back_address
     *
     * @return self
     */
    public function setBackAddress($back_address)
    {
        $this->container['back_address'] = $back_address;

        return $this;
    }

    /**
     * Gets sender
     *
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelSender|null
     */
    public function getSender()
    {
        return $this->container['sender'];
    }

    /**
     * Sets sender
     *
     * @param \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelSender|null $sender sender
     *
     * @return self
     */
    public function setSender($sender)
    {
        $this->container['sender'] = $sender;

        return $this;
    }

    /**
     * Gets sender_mask
     *
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelSenderMask|null
     */
    public function getSenderMask()
    {
        return $this->container['sender_mask'];
    }

    /**
     * Sets sender_mask
     *
     * @param \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelSenderMask|null $sender_mask sender_mask
     *
     * @return self
     */
    public function setSenderMask($sender_mask)
    {
        $this->container['sender_mask'] = $sender_mask;

        return $this;
    }

    /**
     * Gets recipient
     *
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchRecipientAddressModel
     */
    public function getRecipient()
    {
        return $this->container['recipient'];
    }

    /**
     * Sets recipient
     *
     * @param \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchRecipientAddressModel $recipient recipient
     *
     * @return self
     */
    public function setRecipient($recipient)
    {
        $this->container['recipient'] = $recipient;

        return $this;
    }

    /**
     * Gets specific_delivery
     *
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelSpecificDelivery|null
     */
    public function getSpecificDelivery()
    {
        return $this->container['specific_delivery'];
    }

    /**
     * Sets specific_delivery
     *
     * @param \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelSpecificDelivery|null $specific_delivery specific_delivery
     *
     * @return self
     */
    public function setSpecificDelivery($specific_delivery)
    {
        $this->container['specific_delivery'] = $specific_delivery;

        return $this;
    }

    /**
     * Gets cash_on_delivery
     *
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelCashOnDelivery|null
     */
    public function getCashOnDelivery()
    {
        return $this->container['cash_on_delivery'];
    }

    /**
     * Sets cash_on_delivery
     *
     * @param \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelCashOnDelivery|null $cash_on_delivery cash_on_delivery
     *
     * @return self
     */
    public function setCashOnDelivery($cash_on_delivery)
    {
        $this->container['cash_on_delivery'] = $cash_on_delivery;

        return $this;
    }

    /**
     * Gets insurance
     *
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelInsurance|null
     */
    public function getInsurance()
    {
        return $this->container['insurance'];
    }

    /**
     * Sets insurance
     *
     * @param \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelInsurance|null $insurance insurance
     *
     * @return self
     */
    public function setInsurance($insurance)
    {
        $this->container['insurance'] = $insurance;

        return $this;
    }

    /**
     * Gets external_numbers
     *
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchExternalNumberModel[]|null
     */
    public function getExternalNumbers()
    {
        return $this->container['external_numbers'];
    }

    /**
     * Sets external_numbers
     *
     * @param \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchExternalNumberModel[]|null $external_numbers Externí čísla
     *
     * @return self
     */
    public function setExternalNumbers($external_numbers)
    {
        $this->container['external_numbers'] = $external_numbers;

        return $this;
    }

    /**
     * Gets services
     *
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchServiceModel[]|null
     */
    public function getServices()
    {
        return $this->container['services'];
    }

    /**
     * Sets services
     *
     * @param \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchServiceModel[]|null $services Služby
     *
     * @return self
     */
    public function setServices($services)
    {
        $this->container['services'] = $services;

        return $this;
    }

    /**
     * Gets dormant
     *
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelDormant|null
     */
    public function getDormant()
    {
        return $this->container['dormant'];
    }

    /**
     * Sets dormant
     *
     * @param \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelDormant|null $dormant dormant
     *
     * @return self
     */
    public function setDormant($dormant)
    {
        $this->container['dormant'] = $dormant;

        return $this;
    }

    /**
     * Gets shipment_routing
     *
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelShipmentRouting|null
     */
    public function getShipmentRouting()
    {
        return $this->container['shipment_routing'];
    }

    /**
     * Sets shipment_routing
     *
     * @param \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelShipmentRouting|null $shipment_routing shipment_routing
     *
     * @return self
     */
    public function setShipmentRouting($shipment_routing)
    {
        $this->container['shipment_routing'] = $shipment_routing;

        return $this;
    }

    /**
     * Gets direct_injection
     *
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelDirectInjection|null
     */
    public function getDirectInjection()
    {
        return $this->container['direct_injection'];
    }

    /**
     * Sets direct_injection
     *
     * @param \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelDirectInjection|null $direct_injection direct_injection
     *
     * @return self
     */
    public function setDirectInjection($direct_injection)
    {
        $this->container['direct_injection'] = $direct_injection;

        return $this;
    }

    /**
     * Gets label_service
     *
     * @return \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelLabelService|null
     */
    public function getLabelService()
    {
        return $this->container['label_service'];
    }

    /**
     * Sets label_service
     *
     * @param \PPLCZCPL\Model\EpsApiMyApi2WebModelsShipmentBatchShipmentModelLabelService|null $label_service label_service
     *
     * @return self
     */
    public function setLabelService($label_service)
    {
        $this->container['label_service'] = $label_service;

        return $this;
    }
    /**
     * Returns true if offset exists. False otherwise.
     *
     * @param integer $offset Offset
     *
     * @return boolean
     */
    public function offsetExists($offset): bool
    {
        return isset($this->container[$offset]);
    }

    /**
     * Gets offset.
     *
     * @param integer $offset Offset
     *
     * @return mixed|null
     */
    #[\ReturnTypeWillChange]
    public function offsetGet($offset)
    {
        return $this->container[$offset] ?? null;
    }

    /**
     * Sets value based on offset.
     *
     * @param int|null $offset Offset
     * @param mixed    $value  Value to be set
     *
     * @return void
     */
    public function offsetSet($offset, $value): void
    {
        if (is_null($offset)) {
            $this->container[] = $value;
        } else {
            $this->container[$offset] = $value;
        }
    }

    /**
     * Unsets offset.
     *
     * @param integer $offset Offset
     *
     * @return void
     */
    public function offsetUnset($offset): void
    {
        unset($this->container[$offset]);
    }

    /**
     * Serializes the object to a value that can be serialized natively by json_encode().
     * @link https://www.php.net/manual/en/jsonserializable.jsonserialize.php
     *
     * @return mixed Returns data which can be serialized by json_encode(), which is a value
     * of any type other than a resource.
     */
    #[\ReturnTypeWillChange]
    public function jsonSerialize()
    {
       return ObjectSerializerPpl::sanitizeForSerialization($this);
    }

    /**
     * Gets the string presentation of the object
     *
     * @return string
     */
    public function __toString()
    {
        return json_encode(
            ObjectSerializerPpl::sanitizeForSerialization($this),
            JSON_PRETTY_PRINT
        );
    }

    /**
     * Gets a header-safe presentation of the object
     *
     * @return string
     */
    public function toHeaderValue()
    {
        return json_encode(ObjectSerializerPpl::sanitizeForSerialization($this));
    }
}


