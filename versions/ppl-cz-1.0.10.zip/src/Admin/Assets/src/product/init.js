import ProductTab from "./tab";

const InitProductTab = () => {
    const el = jQuery('table[0]');
    const pplNonce = el.data('pplnonce');
    const data = el.data("data");
    const methods = el.data('methods');

    ProductTab(el[0], {
        pplNonce,
        data,
        methods
    });
}

export default InitProductTab;
