


export const Map = (props) => {

    const {
        lat, // number
        lng // number
    } = props;
    if (lat && lng) {
        return <Modal>

        </Modal>
    }

}