# 1.0.11
- úprava filtrace metod dopravy
- oprava přepočtu při výběru jiné měny
# 1.0.12
- odstranění bank account
- opravy
# 1.0.13
- oprava problému s výběrem u mapy při změně země
- oprava chování naplánovaných akcí
- drobné opravy
# 1.0.14
- možnost určení výdejního místa u produktu a kategorie
# 1.0.15
- oprava stahování souboru v případě problému stahování souboru