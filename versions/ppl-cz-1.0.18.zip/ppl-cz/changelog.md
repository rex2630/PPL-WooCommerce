# 1.0.11
- úprava filtrace metod dopravy
- oprava přepočtu při výběru jiné měny
# 1.0.12
- odstranění bank account
- opravy
# 1.0.13
- oprava problému s výběrem u mapy při změně země
- oprava chování naplánovaných akcí
- drobné opravy
# 1.0.14
- možnost určení výdejního místa u produktu a kategorie
# 1.0.15
- oprava stahování souboru v případě problému stahování souboru
# 1.0.16
- oprava příplatku na dobírku v případě různých měn a DPH
# 1.0.17
- oprava hlášky v rácmi chybějících nebo špatných údajů
# 1.0.18
- upravení chování košíku a pokladny v react komponentách